"use strict";
(() => {
  // preview-src/visualizationDocument.ts
  function nonceVisualizationDocument(html, nonce) {
    if (!nonce) {
      return html;
    }
    const parsed = new DOMParser().parseFromString(html, "text/html");
    for (const element of parsed.querySelectorAll("script,style")) {
      element.setAttribute("nonce", nonce);
    }
    const rules = [];
    let index = 0;
    for (const element of parsed.querySelectorAll("[style]")) {
      const name = `visualization-inline-${index++}`;
      rules.push(`.${name}{${element.getAttribute("style")}}`);
      element.removeAttribute("style");
      element.classList.add(name);
    }
    if (rules.length) {
      const styles = parsed.createElement("style");
      styles.setAttribute("nonce", nonce);
      styles.textContent = rules.join("\n");
      parsed.head.append(styles);
    }
    return "<!doctype html>" + parsed.documentElement.outerHTML;
  }

  // preview-src/visualization.ts
  var inheritedNonce = document.currentScript?.nonce || "";
  var channel;
  var frame;
  var activeRevision = "";
  window.addEventListener("message", (event) => {
    if (event.source === window.parent && event.data?.type === "ai-browser-visualization-connect" && event.ports.length === 1 && !channel) {
      channel = event.ports[0];
      channel.onmessage = (incoming) => {
        const data2 = incoming.data;
        if (!data2 || typeof data2 !== "object") {
          return;
        }
        if (data2.type === "render" && typeof data2.html === "string" && data2.html.length <= 1e6 && typeof data2.revision === "string" && /^[a-f0-9]{64}$/.test(data2.revision)) {
          activeRevision = data2.revision;
          const next = document.createElement("iframe");
          next.setAttribute("sandbox", "allow-scripts");
          next.referrerPolicy = "no-referrer";
          next.title = "Visualization content";
          const policy = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; worker-src 'none'";
          const initial = scriptJson({ state: data2.state ?? null, theme: data2.theme });
          next.srcdoc = nonceVisualizationDocument(`<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${policy}"><meta name="referrer" content="no-referrer"><style>${baseStyles}</style><script>(${visualizationRuntime.toString()})(${initial});<\/script></head><body>${data2.html}</body></html>`, inheritedNonce);
          const old = frame;
          frame = next;
          document.body.append(next);
          old?.remove();
        } else if (data2.type === "theme") {
          frame?.contentWindow?.postMessage({ type: "visualization-theme", theme: data2.theme }, "*");
        }
      };
      channel.start();
      channel.postMessage({ type: "ready" });
      return;
    }
    if (!frame || event.source !== frame.contentWindow || !channel || !event.data || typeof event.data !== "object") {
      return;
    }
    const data = event.data;
    if (data.type === "resize" && Number.isFinite(data.height)) {
      channel.postMessage({ type: "resize", height: Math.max(120, Math.min(1200, data.height)), revision: activeRevision });
    } else if (data.type === "state") {
      try {
        if (JSON.stringify(data.state).length <= 16384) {
          channel.postMessage({ type: "state", state: data.state, revision: activeRevision });
        }
      } catch {
      }
    } else if (data.type === "error" && typeof data.message === "string") {
      channel.postMessage({ type: "error", message: data.message.slice(0, 300), revision: activeRevision });
    }
  });
  function scriptJson(value) {
    return JSON.stringify(value).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  }
  function visualizationRuntime(initial) {
    const send = (data) => window.parent.postMessage(data, "*");
    const theme = (colors) => {
      if (!colors || typeof colors !== "object") {
        return;
      }
      for (const [key, value] of Object.entries(colors)) {
        if (/^--[a-z0-9-]{1,50}$/.test(key) && typeof value === "string" && value.length < 160 && !/[;{}<>]/.test(value)) {
          document.documentElement.style.setProperty(key, value);
        }
      }
    };
    theme(initial.theme);
    const api = {
      widgetState: initial.state,
      setWidgetState: async (value) => {
        api.widgetState = value;
        send({ type: "state", state: value });
      }
    };
    Object.defineProperty(window, "openai", { value: api, writable: false });
    window.addEventListener("message", (event) => {
      if (event.source === window.parent && event.data?.type === "visualization-theme") {
        theme(event.data.theme);
      }
    });
    window.addEventListener("error", (event) => send({ type: "error", message: event.message }));
    window.addEventListener("unhandledrejection", (event) => send({ type: "error", message: String(event.reason) }));
    window.addEventListener("DOMContentLoaded", () => {
      let scheduled = false;
      const resize = () => {
        if (scheduled) {
          return;
        }
        scheduled = true;
        requestAnimationFrame(() => {
          scheduled = false;
          send({ type: "resize", height: Math.ceil(document.body.getBoundingClientRect().height) });
        });
      };
      new ResizeObserver(resize).observe(document.body);
      resize();
    });
  }
  var baseStyles = `
:root{color-scheme:light dark;--background:#fff;--foreground:#222;--primary:#2868ce;--border:#bbb;--muted:#eee;--muted-foreground:#666;--font-size-base:14px}
*{box-sizing:border-box}body{margin:0;padding:12px;background:var(--background);color:var(--foreground);font:var(--font-size-base)/1.5 system-ui,sans-serif;overflow-wrap:anywhere}
svg,canvas,img{max-width:100%}button,input,select{font:inherit}button{cursor:pointer}button,.btn{border:1px solid var(--border);border-radius:6px;padding:5px 10px;background:var(--background);color:var(--foreground)}
.card{padding:12px;background:var(--card,var(--background));border:1px solid var(--border);border-radius:8px}.text-small{font-size:.86em}.text-muted{color:var(--muted-foreground)}.tabular-nums{font-variant-numeric:tabular-nums}.btn-primary{background:var(--primary);color:var(--primary-foreground,#fff)}
`;
})();
