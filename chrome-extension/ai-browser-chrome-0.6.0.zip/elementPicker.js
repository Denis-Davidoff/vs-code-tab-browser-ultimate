"use strict";
(() => {
  // src/logins/secretGuards.ts
  function isSecretField(attributes) {
    const type = (attributes.type ?? "").trim().toLowerCase();
    const autocomplete = (attributes.autocomplete ?? "").toLowerCase();
    if (type === "password" || /(^|\s)(current-password|new-password|one-time-code)(\s|$)/.test(autocomplete)) {
      return true;
    }
    return [attributes.name, attributes.id].some((name) => {
      const words = (name ?? "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase();
      return /(^|[^a-z])(pass(word|wd|code|phrase)?|pwd|pin)([^a-z]|$)/.test(words);
    });
  }
  var rawText = /* @__PURE__ */ new Set(["script", "style", "xmp", "iframe", "noembed", "noframes", "noscript", "plaintext"]);
  var rawTextEnd = new Map([...rawText].map((name) => [name, new RegExp(`</${name}`, "gi")]));
  function rawTextClose(html, name, from) {
    const pattern = rawTextEnd.get(name);
    pattern.lastIndex = from;
    return pattern.exec(html)?.index ?? -1;
  }
  function redactSecretValues(html) {
    let result = "";
    let i = 0;
    while (i < html.length) {
      const open = html.indexOf("<", i);
      if (open === -1) {
        result += html.slice(i);
        break;
      }
      result += html.slice(i, open);
      if (html.startsWith("<!--", open)) {
        const end2 = html.indexOf("-->", open + 4);
        const stop = end2 === -1 ? html.length : end2 + 3;
        result += html.slice(open, stop);
        i = stop;
        continue;
      }
      if (html.startsWith("<![CDATA[", open)) {
        const end2 = html.indexOf("]]>", open + 9);
        const stop = end2 === -1 ? html.length : end2 + 3;
        result += html.slice(open, stop);
        i = stop;
        continue;
      }
      const name = /^<([a-zA-Z][^\s/>]*)/.exec(html.slice(open, open + 64))?.[1]?.toLowerCase();
      if (!name) {
        const close = html.indexOf(">", open + 1);
        const stop = close === -1 ? html.length : close + 1;
        result += html.slice(open, stop);
        i = stop;
        continue;
      }
      const end = tagEnd(html, open + name.length + 1);
      const tag = html.slice(open, end);
      result += name === "input" ? redactTag(tag) : tag;
      i = end;
      if (rawText.has(name)) {
        if (name === "plaintext") {
          result += html.slice(i);
          break;
        }
        const closing = rawTextClose(html, name, i);
        const stop = closing === -1 ? html.length : closing;
        result += html.slice(i, stop);
        i = stop;
      }
    }
    return result;
  }
  function tagEnd(html, from) {
    let state = "before";
    for (let at = from; at < html.length; at++) {
      const char = html[at];
      const space = char === " " || char === "	" || char === "\n" || char === "\r" || char === "\f";
      if (state === '"' || state === "'") {
        if (char === state) {
          state = "before";
        }
        continue;
      }
      if (char === ">") {
        return at + 1;
      }
      switch (state) {
        case "before":
          state = space || char === "/" ? "before" : "name";
          break;
        case "name":
          state = space ? "afterName" : char === "/" ? "before" : char === "=" ? "beforeValue" : "name";
          break;
        case "afterName":
          state = space ? "afterName" : char === "/" ? "before" : char === "=" ? "beforeValue" : "name";
          break;
        case "beforeValue":
          state = space ? "beforeValue" : char === '"' || char === "'" ? char : "unquoted";
          break;
        case "unquoted":
          state = space ? "before" : "unquoted";
          break;
      }
    }
    return html.length;
  }
  var attributePattern = /\s([^\s"'>\/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  function redactTag(tag) {
    const attributes = {};
    for (const found of tag.matchAll(attributePattern)) {
      attributes[found[1].toLowerCase()] = found[2] ?? found[3] ?? found[4] ?? "";
    }
    if (!("value" in attributes) || !isSecretField(attributes)) {
      return tag;
    }
    return tag.replace(attributePattern, (whole, name) => name.toLowerCase() === "value" ? "" : whole);
  }

  // chrome-extension/elementPicker.ts
  function captureElement(element) {
    const ancestors = [];
    const path = [];
    let node = element;
    for (let depth = 0; node && depth < 12; depth++) {
      ancestors.unshift({ tagName: node.localName, id: node.id.slice(0, 100), classNames: [...node.classList].slice(0, 4).map((value) => value.slice(0, 80)) });
      let part = node.localName;
      if (node.id) {
        part += `#${CSS.escape(node.id)}`;
      } else if (node.parentElement) {
        const siblings = [...node.parentElement.children].filter((sibling) => sibling.localName === node.localName);
        if (siblings.length > 1) {
          part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
      }
      path.unshift(part);
      if (node.parentElement) {
        node = node.parentElement;
      } else {
        const root = node.getRootNode();
        node = root instanceof ShadowRoot ? root.host : null;
        if (node) {
          path.unshift(">>>");
        }
      }
    }
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const properties = [
      "display",
      "position",
      "box-sizing",
      "width",
      "height",
      "margin",
      "padding",
      "gap",
      "align-items",
      "justify-content",
      "grid-template-columns",
      "flex",
      "color",
      "background-color",
      "border",
      "border-radius",
      "font-family",
      "font-size",
      "font-weight",
      "line-height",
      "text-align",
      "overflow",
      "z-index"
    ];
    const url = new URL(location.href);
    url.username = "";
    url.password = "";
    return {
      outerHTML: redactSecretValues(element.outerHTML).slice(0, 36e3),
      computedStyle: properties.map((property) => `${property}: ${style.getPropertyValue(property)};`).join("\n").slice(0, 12e3),
      ancestors,
      dimensions: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
      url: url.href.slice(0, 2e3),
      selector: path.join(" > ").replace(/ > >>> > /g, " >>> ").slice(0, 2e3)
    };
  }
  var cancelCurrent;
  function startElementPick(id) {
    cancelCurrent?.();
    return new Promise((resolve, reject) => {
      const overlay = document.createElement("div");
      for (const [name, value] of Object.entries({ all: "initial", position: "fixed", inset: "0", "z-index": "2147483647", cursor: "crosshair", "pointer-events": "auto" })) {
        overlay.style.setProperty(name, value, "important");
      }
      const shadow = overlay.attachShadow({ mode: "closed" });
      const highlight = document.createElement("div");
      highlight.style.cssText = "position:fixed;pointer-events:none;border:2px solid #61a9ff;background:#61a9ff25;box-sizing:border-box;display:none;";
      const label = document.createElement("div");
      label.textContent = "Click an element to attach \xB7 Esc to cancel";
      label.style.cssText = "position:fixed;pointer-events:none;top:10px;left:10px;max-width:calc(100vw - 40px);padding:8px 12px;color:white;background:#202835;border:1px solid #61a9ff;border-radius:6px;font:12px/1.5 system-ui;overflow-wrap:anywhere;";
      shadow.append(highlight, label);
      document.documentElement.append(overlay);
      let finished = false;
      const cleanup = () => {
        clearTimeout(timeout);
        overlay.remove();
        window.removeEventListener("keydown", key, true);
        window.removeEventListener("pagehide", cancel);
        if (cancelCurrent === cancel) {
          cancelCurrent = void 0;
        }
      };
      const cancel = (requestId) => {
        if (typeof requestId === "string" && requestId !== id || finished) {
          return;
        }
        finished = true;
        cleanup();
        resolve(void 0);
      };
      const targetAt = (event) => {
        overlay.style.setProperty("pointer-events", "none", "important");
        let target = document.elementFromPoint(event.clientX, event.clientY);
        while (target?.shadowRoot) {
          const inner = target.shadowRoot.elementFromPoint(event.clientX, event.clientY);
          if (!inner || inner === target) {
            break;
          }
          target = inner;
        }
        overlay.style.setProperty("pointer-events", "auto", "important");
        return target;
      };
      const key = (event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopImmediatePropagation();
          cancel();
        }
      };
      const timeout = setTimeout(cancel, 12e4);
      cancelCurrent = cancel;
      window.addEventListener("keydown", key, true);
      window.addEventListener("pagehide", cancel, { once: true });
      overlay.addEventListener("mousemove", (event) => {
        const target = targetAt(event);
        if (!target || target === overlay) {
          return;
        }
        const rect = target.getBoundingClientRect();
        Object.assign(highlight.style, { display: "block", top: `${rect.top}px`, left: `${rect.left}px`, width: `${rect.width}px`, height: `${rect.height}px` });
        label.textContent = `${target.localName}${target.id ? `#${target.id}` : ""} \xB7 Click to attach \xB7 Esc to cancel`;
      });
      overlay.addEventListener("mousedown", (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
      }, true);
      overlay.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (!event.isTrusted || event.button !== 0 || finished) {
          return;
        }
        const target = targetAt(event);
        if (!target || target === overlay) {
          return;
        }
        finished = true;
        cleanup();
        try {
          resolve(captureElement(target));
        } catch (error) {
          reject(error);
        }
      }, true);
    });
  }
  if (typeof window !== "undefined") {
    const world = window;
    world.__aiBrowserChromeElementPicker ??= { start: startElementPick, cancel: (id) => cancelCurrent?.(id) };
  }
})();
