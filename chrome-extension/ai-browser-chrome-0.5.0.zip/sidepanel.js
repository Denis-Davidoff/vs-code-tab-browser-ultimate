"use strict";
(() => {
  // src/chat/chromeChatCompatibility.ts
  var chromeChatProtocolVersion = 2;
  var chromeChatProtocolHeader = "X-AI-Browser-Protocol";
  var chromeChatVersionHeader = "X-AI-Browser-Version";
  function protocol(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : 0;
  }
  function version(value) {
    return typeof value === "string" && /^[0-9]+(?:\.[0-9]+){1,3}(?:-[a-zA-Z0-9.-]+)?$/.test(value) && value.length <= 50 ? value : "unknown";
  }
  function chromeChatCompatibilityError(editorProtocol, chromeProtocol, editorVersion, chromeVersion2) {
    const editor = protocol(editorProtocol), chrome2 = protocol(chromeProtocol);
    if (editor > 0 && editor === chrome2) {
      return void 0;
    }
    const update = editor === chrome2 ? "both AI Browser extensions" : editor < chrome2 ? "the AI Browser extension for VS Code" : "the AI Browser extension for Chrome";
    return `Incompatible AI Browser versions: VS Code ${version(editorVersion)}, Chrome ${version(chromeVersion2)}. Update ${update} to the latest version, then reconnect.`;
  }
  var chromeChatCapabilities = {
    usage: [1],
    context: [1],
    skills: [1],
    workdir: [1],
    git: [1],
    github: [1],
    chat: [1],
    elements: [1],
    screenshots: [1],
    files: [1],
    video: [1],
    page: [1],
    sharedPage: [1],
    annotations: [1]
  };
  var chromeChatCapabilitiesHeader = "X-AI-Browser-Capabilities";
  var transportV2Baseline = {
    chat: [1],
    elements: [1],
    screenshots: [1],
    files: [1],
    video: [1],
    page: [1],
    sharedPage: [1],
    annotations: [1]
  };
  function readChromeChatCapabilities(value, transport) {
    if (value === void 0) {
      return transport === 2 ? transportV2Baseline : {};
    }
    if (typeof value === "string") {
      if (value.length > 4096) {
        return {};
      }
      try {
        value = JSON.parse(value);
      } catch {
        return {};
      }
    }
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return {};
    }
    const entries = Object.entries(value);
    if (entries.length > 64) {
      return {};
    }
    const result = /* @__PURE__ */ Object.create(null);
    for (const [name, versions] of entries) {
      if (!/^[a-zA-Z][a-zA-Z0-9]{0,39}$/.test(name) || !Array.isArray(versions) || versions.length > 16 || !versions.every((v) => Number.isSafeInteger(v) && v > 0)) {
        return {};
      }
      result[name] = [...new Set(versions)];
    }
    return result;
  }
  function negotiateChromeChatCapabilities(peer, transport, local = chromeChatCapabilities) {
    const remote = readChromeChatCapabilities(peer, transport);
    const result = {};
    for (const name of Object.keys(chromeChatCapabilities)) {
      const common = (local[name] ?? []).filter((v) => remote[name]?.includes(v));
      if (common.length) {
        result[name] = Math.max(...common);
      }
    }
    return result;
  }
  function chromeChatFeatureError(feature) {
    return `The ${feature} feature is incompatible or unavailable. Update the AI Browser extensions to the latest version to use it. Other compatible features remain available.`;
  }
  function chromeChatAttachmentFeature(kind) {
    switch (kind) {
      case "screenshot":
        return "screenshots";
      case "file":
        return "files";
      case "annotation":
        return "annotations";
      case "video":
      case "page":
      case "sharedPage":
        return kind;
      default:
        return "elements";
    }
  }
  var chromeChatFooterCommands = {
    usage: ["usage", "dismissUsageAlert"],
    context: ["compact"],
    skills: ["listCommands", "runToolbarSkill", "stopToolbarSkill", "toolbarApprove", "saveToolbarSkill", "deleteToolbarSkill", "moveToolbarSkill", "placeToolbarSkill"],
    workdir: ["listWorkdir", "setWorkdir", "chooseWorkdir", "attachPath"],
    git: ["refreshWorkdirGit", "gitCommit", "gitIndexAction", "openGitDiff", "fixGitCommit", "dismissGitCommit", "gitBranchName", "gitBranchAction", "gitRemoteAction", "restoreBranchStash"],
    github: ["openRepo", "repoAction", "trustWorkdir", "removeRepoFolder"]
  };
  function chromeChatCommandFeature(message) {
    for (const [feature, commands] of Object.entries(chromeChatFooterCommands)) {
      if (commands.includes(message.type)) {
        return feature;
      }
    }
    return "chat";
  }

  // src/chat/toolbarText.ts
  var toolbarNameShape = /^[a-z0-9][a-z0-9:._-]{0,63}$/;
  var toolbarColors = ["red", "orange", "yellow", "green", "blue", "purple"];
  var hexColor = /^#[0-9a-f]{6}$/i;
  var paramNameShape = /^[A-Za-z_][A-Za-z0-9_-]{0,31}$/;
  var iconShape = /^[a-z0-9-]{1,60}$/;
  var toolbarLimits = {
    skills: 30,
    prompt: 2e4,
    /** Prompts after the first: a chain is a few steps, not a script. */
    followUps: 9,
    check: 2e3,
    label: 40,
    tooltip: 200,
    params: 10,
    maxLength: 1e4,
    options: 30,
    option: 100,
    /** A notification's own text, before its placeholders are filled in. */
    notifyText: 500
  };
  function validToolbarSkill(raw) {
    if (!isRecord(raw)) {
      return "Not a skill.";
    }
    const id = typeof raw.id === "string" && /^[A-Za-z0-9-]{1,64}$/.test(raw.id) ? raw.id : void 0;
    if (!id) {
      return "The skill has no id.";
    }
    const name = typeof raw.name === "string" ? raw.name.trim().toLowerCase() : "";
    if (!toolbarNameShape.test(name)) {
      return 'The name is a single word of lower-case letters, digits, "-", "_", ":" or ".", at most 64 characters \u2014 no spaces.';
    }
    const prompt = typeof raw.prompt === "string" ? raw.prompt.trim() : "";
    if (!prompt) {
      return "The prompt is empty.";
    }
    if (prompt.length > toolbarLimits.prompt) {
      return `The prompt is longer than ${toolbarLimits.prompt} characters.`;
    }
    const followUps = [];
    for (const item of Array.isArray(raw.followUps) ? raw.followUps : []) {
      const step = validStep(item, followUps.length + 2);
      if (typeof step === "string") {
        return step;
      }
      if (step) {
        followUps.push(step);
      }
    }
    if (followUps.length > toolbarLimits.followUps) {
      return `A skill sends at most ${toolbarLimits.followUps + 1} prompts.`;
    }
    const result = raw.result === "clipboard" || raw.result === "silent" || raw.result === "toast" ? raw.result : "chat";
    const notify = validNotify(raw.notify);
    if (typeof notify === "string") {
      return notify;
    }
    const agents = raw.agents === "claude" || raw.agents === "codex" || raw.agents === "gemini" ? raw.agents : "all";
    const icon = typeof raw.icon === "string" && iconShape.test(raw.icon) ? raw.icon : "sparkle";
    const colors = validColors(raw.colors, raw.color);
    const label = text(raw.label, toolbarLimits.label);
    const tooltip = text(raw.tooltip, toolbarLimits.tooltip);
    const params = [];
    for (const p of Array.isArray(raw.params) ? raw.params : []) {
      const param = validParam(p);
      if (typeof param === "string") {
        return param;
      }
      if (params.some((q) => q.name === param.name)) {
        return `Two parameters are named "${param.name}".`;
      }
      params.push(param);
    }
    if (params.length > toolbarLimits.params) {
      return `A skill takes at most ${toolbarLimits.params} parameters.`;
    }
    return { id, name, prompt, followUps: followUps.length ? followUps : void 0, result, notify, agents, icon, label, tooltip, colors, params };
  }
  function validNotify(raw) {
    if (!isRecord(raw)) {
      return void 0;
    }
    if (raw.mode === "auto") {
      return { mode: "auto" };
    }
    if (raw.mode !== "text") {
      return void 0;
    }
    const value = typeof raw.text === "string" ? raw.text.trim() : "";
    if (!value) {
      return "The notification text is empty.";
    }
    if (value.length > toolbarLimits.notifyText) {
      return `The notification text is longer than ${toolbarLimits.notifyText} characters.`;
    }
    return { mode: "text", text: value };
  }
  function validStep(raw, number) {
    const from = isRecord(raw) ? raw : { prompt: raw };
    const prompt = typeof from.prompt === "string" ? from.prompt.trim() : "";
    if (!prompt) {
      return void 0;
    }
    if (prompt.length > toolbarLimits.prompt) {
      return `Prompt ${number} is longer than ${toolbarLimits.prompt} characters.`;
    }
    const check = typeof from.check === "string" ? from.check.trim() : "";
    if (check.length > toolbarLimits.check) {
      return `The check before prompt ${number} is longer than ${toolbarLimits.check} characters.`;
    }
    return check ? { prompt, check } : { prompt };
  }
  function validColor(value) {
    return typeof value === "string" && (toolbarColors.includes(value) || hexColor.test(value)) ? value.toLowerCase() : void 0;
  }
  function validColors(raw, legacy) {
    const from = isRecord(raw) ? raw : { text: legacy, icon: legacy };
    const colors = { text: validColor(from.text), border: validColor(from.border), icon: validColor(from.icon) };
    return colors.text || colors.border || colors.icon ? colors : void 0;
  }
  function validParam(raw) {
    if (!isRecord(raw)) {
      return "A parameter is malformed.";
    }
    const name = typeof raw.name === "string" ? raw.name.trim() : "";
    if (!paramNameShape.test(name)) {
      return `"${name.slice(0, 40)}" is not a parameter name: a letter or "_", then letters, digits, "_" or "-", at most 32.`;
    }
    const type = raw.type === "number" || raw.type === "choice" ? raw.type : "text";
    const maxLength = type === "text" && typeof raw.maxLength === "number" && Number.isInteger(raw.maxLength) && raw.maxLength >= 1 && raw.maxLength <= toolbarLimits.maxLength ? raw.maxLength : void 0;
    const options = type === "choice" ? (Array.isArray(raw.options) ? raw.options : []).filter((o) => typeof o === "string").map((o) => o.trim()).filter((o, i, all) => o !== "" && o.length <= toolbarLimits.option && all.indexOf(o) === i).slice(0, toolbarLimits.options) : void 0;
    if (type === "choice" && !options?.length) {
      return `The choice "${name}" lists no values.`;
    }
    const preset = text(raw.preset, maxLength ?? toolbarLimits.maxLength);
    if (preset !== void 0) {
      const problem = valueProblem({ name, type, maxLength, options }, preset);
      if (problem) {
        return `The preset of "${name}": ${problem}`;
      }
    }
    return { name, type, maxLength, preset, options };
  }
  function valueProblem(param, value) {
    const v = value.trim();
    if (!v) {
      return "a value is needed.";
    }
    if (param.type === "number" && !/^-?\d+(\.\d+)?$/.test(v)) {
      return "a number is needed.";
    }
    if (param.type === "choice" && !param.options?.includes(v)) {
      return `one of ${(param.options ?? []).join(", ")}.`;
    }
    if (param.maxLength !== void 0 && Array.from(v).length > param.maxLength) {
      return `at most ${param.maxLength} characters.`;
    }
    return void 0;
  }
  function text(value, limit) {
    if (typeof value !== "string") {
      return void 0;
    }
    const trimmed = value.replace(/\s+/g, " ").trim();
    return trimmed ? Array.from(trimmed).slice(0, limit).join("") : void 0;
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/chat/featureAi.ts
  var featurePromptLimit = 12e3;
  var aiFeatures = ["commitMessage", "branchName", "chatTitle"];
  function readFeatureAiSettings(value) {
    const record = value && typeof value === "object" ? value : {};
    return Object.fromEntries(aiFeatures.map((feature) => {
      const raw = record[feature];
      const choice = raw && typeof raw === "object" ? raw : {};
      return [feature, {
        // Gemini CLI writes no commit messages, branch names or titles here (no one-shot text request yet).
        agent: choice.agent === "claude" || choice.agent === "codex" ? choice.agent : "auto",
        effort: choice.effort === "medium" || choice.effort === "maximum" ? choice.effort : "minimum",
        ...typeof choice.prompt === "string" && choice.prompt.trim() && choice.prompt.length <= featurePromptLimit && !choice.prompt.includes("\0") ? { prompt: choice.prompt.trim() } : {}
      }];
    }));
  }

  // src/chat/chromeChatProtocol.ts
  var chromePairingPorts = Array.from({ length: 20 }, (_, index) => 19371 + index);
  var chromePairingKind = "ai-browser-chrome-pairing";
  function readChromeElementAttachments(value) {
    if (!Array.isArray(value) || value.length > 8) {
      return void 0;
    }
    const attachments = [];
    const ids = /* @__PURE__ */ new Set(), references = /* @__PURE__ */ new Set();
    let length = 0, binaryLength = 0;
    for (const raw of value) {
      if (!raw || typeof raw !== "object" || typeof raw.id !== "string" || !/^[a-zA-Z0-9-]{8,80}$/.test(raw.id) || typeof raw.label !== "string" || raw.label.length > 160 || /[\u0000-\u001f]/.test(raw.label) || typeof raw.reference !== "string" || !/^@[1-9][0-9]{0,5}$/.test(raw.reference) || typeof raw.text !== "string" || !raw.text || raw.text.length > 64e3 || raw.text.includes("\0") || ids.has(raw.id) || references.has(raw.reference)) {
        return void 0;
      }
      length += raw.text.length;
      if (length > 2e5) {
        return void 0;
      }
      ids.add(raw.id);
      references.add(raw.reference);
      if (raw.kind !== void 0 && !["element", "page", "sharedPage", "annotation", "screenshot", "file", "video"].includes(raw.kind)) {
        return void 0;
      }
      if (raw.tabId !== void 0 && (!Number.isSafeInteger(raw.tabId) || raw.tabId < 0 || raw.kind !== "sharedPage")) {
        return void 0;
      }
      if (raw.annotation !== void 0 && (raw.kind !== "annotation" || !raw.annotation || typeof raw.annotation !== "object" || !Number.isSafeInteger(raw.annotation.tabId) || raw.annotation.tabId < 0 || typeof raw.annotation.url !== "string" || raw.annotation.url.length > 2e4 || !/^https?:/.test(raw.annotation.url) || typeof raw.annotation.id !== "string" || !/^[a-f0-9-]{36}$/.test(raw.annotation.id))) {
        return void 0;
      }
      if (raw.file !== void 0) {
        const f = raw.file;
        if (!f || typeof f !== "object" || !["screenshot", "file", "video"].includes(raw.kind) || typeof f.name !== "string" || !f.name || f.name.length > 160 || /[\u0000-\u001f/\\]/.test(f.name) || typeof f.mime !== "string" || !/^[a-zA-Z0-9.+-]+\/[a-zA-Z0-9.+-]+$/.test(f.mime) || typeof f.base64 !== "string" || !f.base64 || f.base64.length % 4 !== 0 || !/^[A-Za-z0-9+/]*={0,2}$/.test(f.base64)) {
          return void 0;
        }
        binaryLength += f.base64.length;
        if (binaryLength > 56e5) {
          return void 0;
        }
      }
      attachments.push({
        id: raw.id,
        label: raw.label,
        reference: raw.reference,
        text: raw.text,
        ...raw.kind ? { kind: raw.kind } : {},
        ...raw.file ? { file: { name: raw.file.name, mime: raw.file.mime, base64: raw.file.base64 } } : {},
        ...raw.tabId !== void 0 ? { tabId: raw.tabId } : {},
        ...raw.annotation ? { annotation: { tabId: raw.annotation.tabId, url: raw.annotation.url, id: raw.annotation.id } } : {}
      });
    }
    return attachments;
  }
  function readChromeChatCommand(value) {
    if (!value || typeof value !== "object") {
      return void 0;
    }
    const raw = value;
    if (typeof raw.id !== "string" || !/^[a-zA-Z0-9-]{8,80}$/.test(raw.id) || typeof raw.chatId !== "string" || raw.chatId.length > 100 || !raw.chatId || !raw.message || typeof raw.message !== "object") {
      return void 0;
    }
    const m = raw.message;
    const attachments = raw.attachments === void 0 ? void 0 : readChromeElementAttachments(raw.attachments);
    if (raw.attachments !== void 0 && (!attachments || m.type !== "send")) {
      return void 0;
    }
    let message;
    switch (m.type) {
      case "setViewMode":
        if (m.mode !== "minimal" && m.mode !== "compact" && m.mode !== "standard") {
          return void 0;
        }
        message = { type: "setViewMode", mode: m.mode };
        break;
      case "saveFeatureAi":
        if (m.recordingSeconds !== void 0 && (typeof m.recordingSeconds !== "number" || !Number.isFinite(m.recordingSeconds))) {
          return void 0;
        }
        message = {
          type: "saveFeatureAi",
          settings: readFeatureAiSettings(m.settings),
          recordingSeconds: m.recordingSeconds,
          ...m.recordingQuality === "balanced" || m.recordingQuality === "high" || m.recordingQuality === "maximum" ? { recordingQuality: m.recordingQuality } : {}
        };
        break;
      case "send":
        if (typeof m.text !== "string" || !m.text.trim() && !attachments?.length || m.text.length > 1e5 || m.text.includes("\0")) {
          return void 0;
        }
        message = { type: "send", text: m.text, ...m.mode === "queue" ? { mode: "queue" } : {} };
        break;
      case "stop":
        message = { type: "stop" };
        break;
      case "switchAgent":
        if (m.choice !== "newTab" && m.choice !== "replace" && m.choice !== "continue" && m.choice !== "cancel") {
          return void 0;
        }
        message = { type: "switchAgent", choice: m.choice };
        break;
      case "select": {
        if (!m.selection || typeof m.selection !== "object") {
          return void 0;
        }
        const s = m.selection;
        if (s.agent !== void 0 && !["claude", "codex", "gemini"].includes(String(s.agent))) {
          return void 0;
        }
        if ([s.model, s.effort].some((v) => v !== void 0 && (typeof v !== "string" || v.length > 200))) {
          return void 0;
        }
        message = { type: "select", selection: {
          agent: s.agent,
          model: s.model,
          effort: s.effort,
          ...typeof s.ultracode === "boolean" ? { ultracode: s.ultracode } : {}
        } };
        break;
      }
      case "approve": {
        if (typeof m.id !== "string" || m.id.length > 200 || typeof m.allow !== "boolean") {
          return void 0;
        }
        const answers = {};
        if (m.answers !== void 0) {
          if (!m.answers || typeof m.answers !== "object" || Array.isArray(m.answers)) {
            return void 0;
          }
          for (const [key, values] of Object.entries(m.answers)) {
            if (key.length > 200 || !Array.isArray(values) || values.length > 100 || values.some((v) => typeof v !== "string" || v.length > 12e3)) {
              return void 0;
            }
            Object.defineProperty(answers, key, { value: values, enumerable: true });
          }
        }
        message = { type: "approve", id: m.id, allow: m.allow, answers };
        break;
      }
      default: {
        const footer = readChromeFooterMessage(m);
        if (!footer) {
          return void 0;
        }
        message = footer;
        break;
      }
    }
    return { id: raw.id, chatId: raw.chatId, message, ...attachments?.length ? { attachments } : {} };
  }
  function readChromeChatConnection(value) {
    if (!value || typeof value !== "object") {
      return void 0;
    }
    const c = value;
    if (c.version !== 1 || typeof c.url !== "string" || !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(c.url) || Number(c.url.split(":").at(-1)) > 65535 || typeof c.token !== "string" || !/^[a-f0-9]{64}$/.test(c.token) || typeof c.extensionId !== "string" || !/^[a-p]{32}$/.test(c.extensionId)) {
      return void 0;
    }
    if (c.protocolVersion !== void 0 && (typeof c.protocolVersion !== "number" || !Number.isSafeInteger(c.protocolVersion) || c.protocolVersion < 1)) {
      return void 0;
    }
    if (c.editorVersion !== void 0 && (typeof c.editorVersion !== "string" || c.editorVersion.length > 50)) {
      return void 0;
    }
    if (c.deliverySession !== void 0 && (typeof c.deliverySession !== "string" || !/^[a-f0-9]{32}$/.test(c.deliverySession))) {
      return void 0;
    }
    return {
      version: 1,
      ...c.deliverySession ? { deliverySession: c.deliverySession } : {},
      url: c.url,
      token: c.token,
      extensionId: c.extensionId,
      ...c.capabilities !== void 0 ? { capabilities: readChromeChatCapabilities(c.capabilities, c.protocolVersion) } : {},
      ...c.protocolVersion !== void 0 ? { protocolVersion: c.protocolVersion } : {},
      ...c.editorVersion !== void 0 ? { editorVersion: c.editorVersion } : {}
    };
  }
  function readChromeFooterMessage(m) {
    const text2 = (key, max = 4096, optional = false) => m[key] === void 0 ? optional : typeof m[key] === "string" && m[key].length <= max && !m[key].includes("\0");
    const tab = () => text2("tabId", 100) && !!m.tabId;
    const folder = () => text2("folder") && !!m.folder;
    switch (m.type) {
      case "usage":
      case "listWorkdir":
      case "chooseWorkdir":
      case "refreshWorkdirGit":
      case "trustWorkdir":
        return { type: m.type };
      case "compact":
        return tab() ? { type: m.type, tabId: m.tabId } : void 0;
      case "setWorkdir":
        return text2("path", 4096, true) ? { type: m.type, path: m.path } : void 0;
      case "attachPath":
      case "removeRepoFolder":
        return text2("path") ? { type: m.type, path: m.path } : void 0;
      case "listCommands":
        return ["claude", "codex", "gemini"].includes(String(m.agent)) ? { type: m.type, agent: m.agent } : void 0;
      case "runToolbarSkill": {
        if (!text2("id", 200) || !text2("tabId", 100, true) || !m.values || typeof m.values !== "object" || Array.isArray(m.values)) {
          return void 0;
        }
        const values = Object.entries(m.values);
        if (values.length > 100 || values.some(([key, v]) => key.length > 200 || typeof v !== "string" || v.length > 12e3 || v.includes("\0"))) {
          return void 0;
        }
        return { type: m.type, id: m.id, tabId: m.tabId, values: Object.fromEntries(values), again: m.again === true, queue: m.queue === true };
      }
      case "saveToolbarSkill": {
        const skill = validToolbarSkill(m.skill);
        return typeof skill === "string" ? void 0 : { type: m.type, skill };
      }
      case "deleteToolbarSkill":
      case "stopToolbarSkill":
        return text2("id", 200) ? { type: m.type, id: m.id } : void 0;
      case "moveToolbarSkill":
        return text2("id", 200) && (m.by === -1 || m.by === 1) ? { type: m.type, id: m.id, by: m.by } : void 0;
      case "placeToolbarSkill":
        return text2("id", 200) && text2("target", 200) && typeof m.after === "boolean" ? { type: m.type, id: m.id, target: m.target, after: m.after } : void 0;
      case "toolbarApprove":
        return text2("id", 200) && text2("approvalId", 200) && typeof m.allow === "boolean" ? { type: m.type, id: m.id, approvalId: m.approvalId, allow: m.allow } : void 0;
      case "gitCommit":
        return folder() && tab() && (m.scope === void 0 || m.scope === "all" || m.scope === "staged") ? { type: m.type, folder: m.folder, tabId: m.tabId, scope: m.scope } : void 0;
      case "gitIndexAction":
        return folder() && tab() && ["stage", "unstage"].includes(String(m.action)) && text2("path", 4096, true) ? { type: m.type, folder: m.folder, tabId: m.tabId, action: m.action, path: m.path } : void 0;
      case "openGitDiff":
        return folder() && tab() && text2("path") && typeof m.staged === "boolean" ? { type: m.type, folder: m.folder, tabId: m.tabId, path: m.path, staged: m.staged } : void 0;
      case "fixGitCommit":
      case "dismissGitCommit":
        return folder() && tab() && text2("id", 200) ? { type: m.type, folder: m.folder, tabId: m.tabId, id: m.id } : void 0;
      case "gitBranchName":
        return folder() && tab() && Number.isSafeInteger(m.id) && m.id >= 0 ? { type: m.type, folder: m.folder, tabId: m.tabId, id: m.id } : void 0;
      case "gitBranchAction":
        return folder() && text2("name", 1024) && ["switch", "create", "delete"].includes(String(m.action)) ? { type: m.type, folder: m.folder, name: m.name, action: m.action, remote: m.remote === true } : void 0;
      case "gitRemoteAction":
        return folder() && ["publish", "push", "pull"].includes(String(m.action)) && text2("remote", 200, true) && text2("confirmed", 4096, true) ? { type: m.type, folder: m.folder, action: m.action, remote: m.remote, confirmed: m.confirmed } : void 0;
      case "restoreBranchStash":
        return folder() ? { type: m.type, folder: m.folder } : void 0;
      case "openRepo":
        return text2("repo", 2048) && text2("branch", 1024) && ["copy", "clone", "reference"].includes(String(m.mode)) ? { type: m.type, repo: m.repo, branch: m.branch, mode: m.mode } : void 0;
      case "repoAction":
        return ["changes", "push", "window", "remove"].includes(String(m.action)) ? { type: m.type, action: m.action } : void 0;
      case "dismissUsageAlert": {
        const a = m.alert;
        return a && ["claude", "codex", "gemini"].includes(String(a.agent)) && typeof a.label === "string" && a.label.length <= 200 && typeof a.percent === "number" && Number.isFinite(a.percent) && ["high", "reached", "credits"].includes(String(a.kind)) ? { type: m.type, alert: { agent: a.agent, label: a.label, percent: a.percent, kind: a.kind } } : void 0;
      }
      default:
        return void 0;
    }
  }

  // src/elements/elementMarkdown.ts
  function oneLine(value) {
    return value.replace(
      /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/g,
      (ch) => `\\u${ch.charCodeAt(0).toString(16).padStart(4, "0")}`
    );
  }
  function inertProse(value) {
    return value.replace(/\]\(/g, "]\\(").replace(/</g, "&lt;");
  }
  function formatAncestor(ancestor) {
    const id = ancestor.id ? `#${ancestor.id}` : "";
    const classes = ancestor.classNames?.length ? `.${ancestor.classNames.join(".")}` : "";
    return oneLine(`${ancestor.tagName}${id}${classes}`);
  }
  function fence(content, language) {
    let longest = 0;
    for (const run of content.match(/`+/g) ?? []) {
      longest = Math.max(longest, run.length);
    }
    const marks = "`".repeat(Math.max(3, longest + 1));
    return `${marks}${language}
${content}
${marks}`;
  }
  function renderElementMarkdown(data, url) {
    const sections = [];
    sections.push("Attached Element Context from Integrated Browser");
    const self = data.ancestors.at(-1);
    if (self) {
      sections.push(`Element: ${inertProse(formatAncestor(self))}`);
    }
    if (url) {
      sections.push(`URL: ${inertProse(oneLine(url))}`);
    }
    if (data.ancestors.length) {
      sections.push(`HTML Path: ${inertProse(data.ancestors.map(formatAncestor).join(" > "))}`);
    }
    sections.push(`Outer HTML:
${fence(data.outerHTML, "html")}`);
    const { top, left, width, height } = data.dimensions;
    sections.push(
      `Dimensions:
- top: ${Math.round(top)}px
- left: ${Math.round(left)}px
- width: ${Math.round(width)}px
- height: ${Math.round(height)}px`
    );
    sections.push(`CSS:
${fence(data.computedStyle, "css")}`);
    return sections.join("\n\n");
  }

  // src/browser/annotationData.ts
  var annotationColors = ["#2563eb", "#7c3aed", "#be185d", "#b91c1c", "#c2410c", "#a16207", "#15803d", "#0f766e", "#0369a1", "#475569"];
  function annotationClipboardText(record, url) {
    const element2 = `<${record.element.tag}>${record.element.selector ? ` ${record.element.selector}` : ""}${record.element.text ? ` \u2014 "${record.element.text}"` : ""}`;
    return [
      record.text.trim() || "(empty note)",
      "",
      `Annotation #${record.number} on ${url}`,
      `Element: ${element2}`
    ].join("\n");
  }
  function parseAnnotations(value) {
    if (!Array.isArray(value) || value.length > 50) {
      throw new Error("Invalid annotation list.");
    }
    const ids = /* @__PURE__ */ new Set(), numbers = /* @__PURE__ */ new Set();
    return value.map((record) => {
      const string = (v, max) => {
        if (typeof v !== "string" || v.length > max) {
          throw new Error("Invalid annotation text.");
        }
        return v;
      };
      if (!record || typeof record !== "object" || !record.element || typeof record.element !== "object" || !Number.isSafeInteger(record.number) || record.number < 1 || record.number > 1e6 || !Number.isSafeInteger(record.createdAt) || record.createdAt < 0 || typeof record.element.strong !== "boolean") {
        throw new Error("Invalid annotation.");
      }
      const id = string(record.id, 80);
      if (!/^[a-f0-9-]{36}$/.test(id) || ids.has(id) || numbers.has(record.number)) {
        throw new Error("Duplicate or invalid annotation identity.");
      }
      ids.add(id);
      numbers.add(record.number);
      const color = record.color === void 0 ? annotationColors[0] : string(record.color, 7);
      if (!annotationColors.includes(color)) {
        throw new Error("Invalid annotation color.");
      }
      return { id, number: record.number, createdAt: record.createdAt, text: string(record.text, 2e3), color, element: {
        selector: string(record.element.selector, 4e3),
        strong: record.element.strong,
        tag: string(record.element.tag, 100),
        text: string(record.element.text, 180),
        role: string(record.element.role, 80)
      } };
    }).sort((a, b) => a.number - b.number);
  }

  // chrome-extension/annotations.ts
  var ChromeAnnotations = class {
    constructor(changed, error) {
      this.changed = changed;
      this.error = error;
    }
    changed;
    error;
    tabs = /* @__PURE__ */ new Map();
    locks = /* @__PURE__ */ new Map();
    polling;
    serial(tabId, work) {
      const pending = (this.locks.get(tabId) ?? Promise.resolve()).catch(() => {
      }).then(work);
      this.locks.set(tabId, pending);
      void pending.finally(() => {
        if (this.locks.get(tabId) === pending) {
          this.locks.delete(tabId);
        }
      }).catch(() => {
      });
      return pending;
    }
    snapshot() {
      return [...this.tabs.values()];
    }
    async save() {
      await chrome.storage.session.set({ annotationTabs: this.snapshot() });
    }
    restore(value) {
      if (!Array.isArray(value)) {
        return;
      }
      for (const raw of value.slice(0, 8)) {
        try {
          if (!raw || !Number.isSafeInteger(raw.tabId) || raw.tabId < 0 || typeof raw.chatId !== "string" || raw.chatId.length > 100 || typeof raw.url !== "string" || !Number.isSafeInteger(raw.nextNumber) || !Array.isArray(raw.pages) || raw.pages.length > 8) {
            continue;
          }
          const pages = raw.pages.map((page) => {
            if (typeof page.url !== "string" || page.url.length > 2e4) {
              throw new Error("Invalid annotation URL");
            }
            return { url: page.url, records: parseAnnotations(page.records), found: [] };
          });
          const owners = raw.owners && typeof raw.owners === "object" ? Object.fromEntries(Object.entries(raw.owners).filter(([id, chat]) => /^[a-f0-9-]{36}$/.test(id) && typeof chat === "string" && chat.length <= 100)) : {};
          const chatIds = [.../* @__PURE__ */ new Set([raw.chatId, ...raw.chatIds === void 0 ? Object.values(owners) : Array.isArray(raw.chatIds) ? raw.chatIds.filter((chat) => typeof chat === "string" && chat.length > 0 && chat.length <= 100).slice(0, 1e3) : []])];
          this.tabs.set(raw.tabId, {
            tabId: raw.tabId,
            chatId: raw.chatId,
            chatIds,
            url: raw.url,
            nextNumber: Math.max(1, raw.nextNumber),
            pages,
            owners,
            dismissed: Array.isArray(raw.dismissed) ? raw.dismissed.filter((id) => typeof id === "string").slice(0, 400) : [],
            sent: Array.isArray(raw.sent) ? raw.sent.filter((id) => typeof id === "string").slice(0, 400) : [],
            assistant: Array.isArray(raw.assistant) ? raw.assistant.filter((id) => typeof id === "string").slice(0, 400) : []
          });
        } catch {
        }
      }
    }
    async inject(tabId) {
      await chrome.scripting.executeScript({ target: { tabId }, world: "ISOLATED", files: ["annotationOverlay.js"] });
    }
    async read(tabId) {
      const result = await chrome.scripting.executeScript({ target: { tabId }, world: "ISOLATED", func: () => {
        const world = window;
        return { snapshot: world.__aiBrowserAnnotations?.collect(), events: world.__aiBrowserChromeAnnotationEvents?.splice(0) ?? [] };
      } });
      return result[0]?.result;
    }
    page(tab, url) {
      let page = tab.pages.find((page2) => page2.url === url);
      if (!page) {
        if (tab.pages.length >= 8) {
          tab.pages = tab.pages.filter((page2) => page2.records.length > 0);
        }
        if (tab.pages.length >= 8) {
          throw new Error("This tab already has annotations on 8 pages. Remove some annotations first.");
        }
        page = { url, records: [], found: [] };
        tab.pages.push(page);
      }
      return page;
    }
    async hydrate(tab, start) {
      const page = this.page(tab, tab.url);
      await chrome.scripting.executeScript({
        target: { tabId: tab.tabId },
        world: "ISOLATED",
        func: (url, records, nextNumber, start2) => {
          if (location.href !== url) {
            throw new Error("The page navigated. Try again.");
          }
          const api = window.__aiBrowserAnnotations;
          if (!api) {
            throw new Error("Annotations unavailable.");
          }
          if (start2) {
            api.start({ records, nextNumber });
          } else {
            api.hydrate({ records, nextNumber });
          }
        },
        args: [tab.url, page.records, tab.nextNumber, start]
      });
    }
    async start(tabId, chatId) {
      await this.serial(tabId, async () => {
        const browserTab = await chrome.tabs.get(tabId);
        if (!browserTab.url || !/^https?:/.test(browserTab.url)) {
          throw new Error("Open a regular website in Chrome first.");
        }
        let tab = this.tabs.get(tabId);
        const fresh = !tab;
        if (!tab) {
          if (this.tabs.size >= 8) {
            throw new Error("Annotations are already active in 8 tabs.");
          }
          tab = { tabId, chatId, chatIds: [chatId], url: browserTab.url, nextNumber: 1, pages: [], assistant: [], dismissed: [], sent: [], owners: {} };
          this.tabs.set(tabId, tab);
        }
        await this.inject(tabId);
        if (!fresh) {
          await this.collect(tab);
        }
        tab.dismissed = [];
        tab.chatId = chatId;
        tab.url = browserTab.url;
        if (!tab.chatIds.includes(chatId)) {
          tab.chatIds.push(chatId);
        }
        const page = this.page(tab, tab.url);
        if (page.records.length >= 50) {
          throw new Error("This page already has 50 annotations. Remove a note first.");
        }
        await this.hydrate(tab, true);
        this.changed(tab, page, true);
        await this.save();
      });
    }
    async collect(tab) {
      const data = await this.read(tab.tabId);
      if (this.tabs.get(tab.tabId) !== tab) {
        return;
      }
      if (!data?.snapshot) {
        const browserTab = await chrome.tabs.get(tab.tabId);
        if (!browserTab.url || !/^https?:/.test(browserTab.url)) {
          tab.url = browserTab.url ?? "";
          return;
        }
        tab.url = browserTab.url;
        await this.inject(tab.tabId);
        await this.hydrate(tab, false);
        return;
      }
      const { snapshot, events } = data;
      if (snapshot.url !== tab.url) {
        tab.url = snapshot.url;
        await this.hydrate(tab, false);
        return;
      }
      const page = this.page(tab, tab.url);
      const records = parseAnnotations(snapshot.records);
      page.found = snapshot.records.filter((record) => record.elementFound).map((record) => record.id);
      if (JSON.stringify(page.records) !== JSON.stringify(records)) {
        for (const record of records) {
          if (!tab.assistant.includes(record.id)) {
            tab.owners[record.id] ??= tab.chatId;
          }
        }
        page.records = records;
        tab.nextNumber = Math.max(tab.nextNumber, ...records.map((record) => record.number + 1));
        this.changed(tab, page);
        await this.save();
      }
      for (const event of events) {
        const record = page.records.find((record2) => record2.id === event.id);
        if (!record || event.url !== tab.url) {
          continue;
        }
        if (event.type === "copy") {
          await navigator.clipboard.writeText(annotationClipboardText(record, tab.url));
        }
        if (event.type === "requestDelete" && (!record.text.trim() || window.confirm(`Delete annotation #${record.number}?

${record.text}`))) {
          await this.removeNow(tab, page.url, [record.id]);
        }
      }
    }
    async poll() {
      if (!this.polling) {
        this.polling = Promise.all([...this.tabs.values()].map((tab) => this.serial(tab.tabId, () => this.collect(tab)).catch(this.error))).then(() => {
        }).finally(() => {
          this.polling = void 0;
        });
      }
      return this.polling;
    }
    async removeNow(tab, url, ids) {
      const page = tab.pages.find((page2) => page2.url === url);
      if (!page) {
        return;
      }
      const browserTab = await chrome.tabs.get(tab.tabId);
      if (browserTab.url === url) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.tabId },
          world: "ISOLATED",
          func: (ids2, url2) => window.__aiBrowserAnnotations?.remove(ids2, url2),
          args: [ids, url]
        });
      }
      page.records = page.records.filter((record) => !ids.includes(record.id));
      for (const id of ids) {
        delete tab.owners[id];
      }
      this.changed(tab, page);
      await this.save();
    }
    async remove(tabId, url, ids) {
      await this.serial(tabId, async () => {
        const tab = this.tabs.get(tabId);
        if (tab) {
          await this.removeNow(tab, url, ids);
        }
      });
    }
    dismiss(tabId, id) {
      const tab = this.tabs.get(tabId);
      if (tab && !tab.dismissed.includes(id)) {
        tab.dismissed.push(id);
        void this.save().catch(this.error);
      }
    }
    sent(tabId, id) {
      const tab = this.tabs.get(tabId);
      if (tab && !tab.sent.includes(id)) {
        tab.sent.push(id);
        void this.save().catch(this.error);
      }
    }
    async retainChats(chats) {
      for (const tab of [...this.tabs.values()]) {
        const previous = tab.chatIds.length;
        tab.chatIds = tab.chatIds.filter((chat) => chats.has(chat));
        for (const page of tab.pages) {
          const removed = page.records.filter((record) => tab.owners[record.id] && !chats.has(tab.owners[record.id])).map((record) => record.id);
          if (removed.length) {
            await this.remove(tab.tabId, page.url, removed);
          }
        }
        if (tab.chatIds.length) {
          if (!tab.chatIds.includes(tab.chatId)) {
            tab.chatId = tab.chatIds[0];
          }
          if (tab.chatIds.length !== previous) {
            await this.save();
          }
          continue;
        }
        this.closed(tab.tabId);
        try {
          await chrome.scripting.executeScript({ target: { tabId: tab.tabId }, world: "ISOLATED", func: () => window.__aiBrowserAnnotations?.dispose() });
        } catch {
        }
      }
    }
    async execute(request2) {
      return this.serial(request2.tabId, async () => {
        const tab = this.tabs.get(request2.tabId);
        if (!tab || !tab.chatIds.includes(request2.chatId) || request2.action !== "remove" && tab.url !== request2.url) {
          throw new Error("The annotated page changed or is no longer available.");
        }
        if (request2.action === "remove") {
          await this.removeNow(tab, request2.url, request2.ids ?? []);
          return { removed: request2.ids?.length ?? 0 };
        }
        if (!request2.annotationId) {
          throw new Error("Missing annotation ID.");
        }
        if (!tab.assistant.includes(request2.annotationId)) {
          tab.assistant.push(request2.annotationId);
        }
        const result = await chrome.scripting.executeScript({
          target: { tabId: request2.tabId },
          world: "ISOLATED",
          func: (url, selector, text2, color, id) => {
            if (location.href !== url) {
              throw new Error("The page navigated.");
            }
            const api = window.__aiBrowserAnnotations;
            const existing = api?.collect().records.find((record) => record.id === id);
            return existing ? { id, number: existing.number, url } : api?.add(selector, text2, color, id);
          },
          args: [request2.url, request2.selector ?? "", request2.text ?? "", request2.color ?? "#2563eb", request2.annotationId]
        });
        const value = result[0]?.result;
        if (!value || value.error) {
          throw new Error(value?.error ?? "Could not add the annotation.");
        }
        await this.collect(tab);
        return value;
      });
    }
    closed(tabId) {
      const tab = this.tabs.get(tabId);
      if (!tab) {
        return;
      }
      this.tabs.delete(tabId);
      for (const page of tab.pages) {
        this.changed(tab, { ...page, records: [] });
      }
      void this.save().catch(this.error);
    }
  };

  // chrome-extension/elementDrafts.ts
  function appendPickedElement(draft, element2) {
    if (draft.attachments.length >= 8 || draft.attachments.reduce((size, item) => size + item.text.length, element2.text.length) > 2e5) {
      throw new Error("Remove an attachment before adding another (maximum 8 attachments / 200,000 characters).");
    }
    draft.next = Math.max(draft.next, ...draft.attachments.map((item) => Number(item.reference.slice(1)) + 1));
    draft.attachments.push({ ...element2, reference: `@${draft.next++}` });
  }
  function restorePickedElements(draft, attachments, text2) {
    const renamed = /* @__PURE__ */ new Map();
    draft.next = Math.max(draft.next, ...draft.attachments.map((item) => Number(item.reference.slice(1)) + 1));
    for (const attachment of attachments) {
      const existing = draft.attachments.find((item) => item.id === attachment.id);
      const reference = existing?.reference ?? `@${draft.next++}`;
      if (!existing) {
        draft.attachments.push({ ...attachment, reference });
      }
      renamed.set(attachment.reference, reference);
    }
    return text2.replace(/@\d+\b/g, (reference) => renamed.get(reference) ?? reference);
  }

  // chrome-extension/sidepanel.ts
  function element(id) {
    const node = document.getElementById(id);
    if (!node) {
      throw new Error(`Missing panel element: ${id}`);
    }
    return node;
  }
  var pairing = element("pairing");
  var code = element("connection");
  var status = element("status");
  var app = element("app");
  var disconnect = element("disconnect");
  var conversation = element("conversation");
  var modeButton = element("mode");
  var modeDetails = element("mode-details");
  var modeText = element("mode-text");
  var modeOpen = false;
  var modeShownLimited = false;
  modeButton.addEventListener("click", () => {
    modeOpen = !modeOpen;
    renderMode();
  });
  element("mode-close").addEventListener("click", () => {
    modeOpen = false;
    renderMode();
    modeButton.focus();
  });
  var modeExplanations = {
    full: "Full mode: this Chrome was opened from VS Code, so the agents\u2019 browser tools see and drive its tabs \u2014 reading pages, clicking, filling forms, screenshots \u2014 alongside everything in this panel.",
    limited: "Limited mode: this Chrome was not opened from VS Code, so the agents cannot see or act on its pages. You can still chat, pick elements, attach screenshots and page addresses here. For every function, open Chrome from VS Code: in the AI Browser chat press the globe (Open browser) and choose Google Chrome, then use this panel in that window."
  };
  function renderMode() {
    const mode = latest?.agentChrome === void 0 ? void 0 : latest.agentChrome ? "full" : "limited";
    modeButton.hidden = !mode;
    if (!mode) {
      modeDetails.hidden = true;
      return;
    }
    if (mode === "limited" && !modeShownLimited) {
      modeShownLimited = true;
      modeOpen = true;
    }
    modeButton.dataset.mode = mode;
    modeDetails.dataset.mode = mode;
    modeButton.textContent = mode === "full" ? "Full mode" : "Limited mode";
    modeButton.title = `${modeExplanations[mode]}
Click to ${modeOpen ? "hide" : "show"} details.`;
    modeButton.setAttribute("aria-expanded", String(modeOpen));
    modeText.textContent = modeExplanations[mode];
    modeDetails.hidden = !modeOpen;
  }
  var quickConnect = element("quick-connect");
  var cancelConnect = element("cancel-connect");
  var editorSources = element("editor-sources");
  var pickerControls = element("element-picker-controls");
  var pickerStatus = element("element-picker-status");
  var cancelElementPick = element("cancel-element-pick");
  var elementDrafts = /* @__PURE__ */ Object.create(null);
  var activePage;
  var picking;
  var quickAttempt;
  element("extension-id").textContent = chrome.runtime.id;
  var active;
  var latest;
  var etag;
  var timer;
  var request;
  var generation = 0;
  var failures = 0;
  var compatible = false;
  var chromeVersion = chrome.runtime.getManifest().version;
  var draftState = {};
  var outbox = [];
  var outboxSession;
  var persisted = /* @__PURE__ */ new Set();
  var outboxWrite = Promise.resolve();
  var flushing = false;
  var feedback;
  var pairingPending = false;
  var supported = /* @__PURE__ */ new Set([...Object.values(chromeChatFooterCommands).flat(), "send", "stop", "select", "switchAgent", "approve", "setViewMode", "saveFeatureAi"]);
  var passive = /* @__PURE__ */ new Set(["ready", "saveDrafts", "tabDraft"]);
  function emit(message) {
    window.dispatchEvent(new MessageEvent("message", { data: message }));
  }
  function render() {
    if (!latest?.view) {
      return;
    }
    app.hidden = false;
    renderConversations(latest);
    renderMode();
    if (resumeState && resumeState.chatId !== latest.chatId) {
      void saveResume({ ...resumeState, chatId: latest.chatId });
    }
    const view = latest.view;
    const light = view.themeKind === 1 || view.themeKind === 4;
    document.documentElement.style.colorScheme = light ? "light" : "dark";
    for (const name of ["vscode-light", "vscode-dark", "vscode-high-contrast", "vscode-high-contrast-light"]) {
      document.body.classList.remove(name);
    }
    document.body.classList.add(view.themeKind === 4 ? "vscode-high-contrast-light" : view.themeKind === 3 ? "vscode-high-contrast" : light ? "vscode-light" : "vscode-dark");
    for (const [key, value] of Object.entries(view.themeTokens ?? {})) {
      if (/^--vscode-[a-zA-Z0-9-]+$/.test(key)) {
        document.documentElement.style.setProperty(key, value);
      }
    }
    emit({ type: "state", state: {
      ...view,
      browserApi: true,
      nativeBrowser: "unsupported",
      hasBrowserTab: activePage?.id !== void 0,
      attachments: (elementDrafts[latest.chatId]?.attachments ?? []).map((item) => ({ id: item.id, kind: item.kind ?? "element", label: item.label, reference: item.reference })),
      blocked: latest.canSend ? view.blocked : "Update the editor extension to enable sending from Chrome.",
      entries: feedback ? [...view.entries, { kind: "notice", text: feedback }] : view.entries
    } });
  }
  function renderConversations(snapshot) {
    const tabs = snapshot.view.tabs;
    const signature = JSON.stringify([snapshot.chatId, tabs.map((tab) => [tab.chatId, tab.title, tab.busy])]);
    conversation.hidden = tabs.length < 2;
    if (conversation.dataset.signature === signature || document.activeElement === conversation) {
      return;
    }
    conversation.dataset.signature = signature;
    conversation.replaceChildren(...tabs.map((tab) => {
      const option = document.createElement("option");
      option.value = tab.chatId;
      option.textContent = `${tab.busy ? "\u25CF " : ""}${tab.title}`;
      return option;
    }));
    conversation.value = snapshot.chatId;
  }
  var pinning = 0;
  conversation.addEventListener("change", () => {
    const connection = active, chatId = conversation.value, current = generation, request2 = ++pinning;
    if (!connection || !latest || chatId === latest.chatId) {
      return;
    }
    conversation.disabled = true;
    void fetch(`${connection.url}/command`, {
      method: "POST",
      headers: bridgeHeaders(connection, true),
      body: JSON.stringify({ id: crypto.randomUUID(), chatId, message: { type: "pin" } }),
      signal: AbortSignal.timeout(1e4)
    }).then(async (response) => {
      const result = await response.json().catch(() => ({}));
      if (current !== generation || request2 !== pinning) {
        return;
      }
      if (response.status === 426) {
        requireUpdate(result.error ?? "Update both AI Browser extensions.");
        return;
      }
      if (!response.ok) {
        throw new Error(result.error ?? "Could not switch conversations.");
      }
      cancelPick();
      feedback = void 0;
      etag = void 0;
      if (result.snapshot?.view) {
        latest = result.snapshot;
      }
    }).catch((error) => {
      if (current === generation && request2 === pinning) {
        feedback = error instanceof Error ? error.message : "Could not switch conversations.";
      }
    }).finally(() => {
      if (current !== generation || request2 !== pinning) {
        return;
      }
      conversation.disabled = false;
      delete conversation.dataset.signature;
      render();
    });
  });
  function showFeedback(text2) {
    feedback = text2;
    render();
  }
  function persistOutbox() {
    const saved = outbox.slice();
    const drafts = JSON.parse(JSON.stringify(elementDrafts));
    const footerPosition = { token: active?.token, deliverySession: active?.deliverySession, cursor: footerCursor };
    const deliverySession = outboxSession;
    outboxWrite = outboxWrite.catch(() => {
    }).then(() => chrome.storage.session.set({ outbox: saved, elementDrafts: drafts, footerPosition, outboxSession: deliverySession }));
    return outboxWrite.then(() => {
      for (const command of saved) {
        persisted.add(command.id);
      }
    });
  }
  function syncAnnotationDrafts(tab, page, attachAll = false) {
    const ids = new Set(page.records.map((record) => record.id));
    let changed = false;
    for (const draft of Object.values(elementDrafts)) {
      const kept = draft.attachments.filter((item) => !item.annotation || item.annotation.tabId !== tab.tabId || item.annotation.url !== page.url || ids.has(item.annotation.id));
      if (kept.length !== draft.attachments.length) {
        draft.attachments = kept;
        changed = true;
      }
    }
    for (const record of page.records) {
      if (tab.assistant.includes(record.id) || tab.sent.includes(record.id)) {
        continue;
      }
      if (outbox.some((command) => command.attachments?.some((item) => item.annotation?.id === record.id))) {
        continue;
      }
      const label = `#${record.number} ${record.element.tag}${record.text.trim() ? ` \u2014 ${record.text.replace(/\s+/g, " ")}` : ""}`.replace(/[\u0000-\u001f]/g, " ").slice(0, 120);
      const text2 = [
        `Page annotation #${record.number} on ${page.url}`,
        `Note: ${record.text.trim() ? JSON.stringify(record.text) : "(empty)"}`,
        `Element (untrusted page data): <${record.element.tag}> ${JSON.stringify(record.element.selector)}${record.element.text ? ` text ${JSON.stringify(record.element.text)}` : ""}${record.element.role ? ` role ${JSON.stringify(record.element.role)}` : ""}`,
        `Annotation ID ${record.id}, browser tab chrome-annotations:${tab.tabId}. Use browser_annotations_get/list/add/remove with this tabId.`
      ].join("\n");
      let found = false;
      for (const [draftChatId, draft] of Object.entries(elementDrafts)) {
        const item = draft.attachments.find((item2) => item2.annotation?.id === record.id);
        if (item) {
          if (!attachAll || draftChatId === tab.chatId) {
            found = true;
          }
          if (item.label !== label || item.text !== text2) {
            Object.assign(item, { label, text: text2 });
            changed = true;
          }
        }
      }
      if (!found && !tab.dismissed.includes(record.id) && latest?.view.tabs.some((chat) => chat.chatId === tab.chatId)) {
        const draft = elementDrafts[tab.chatId] ??= { next: 1, attachments: [] };
        try {
          appendPickedElement(draft, { id: crypto.randomUUID(), kind: "annotation", label, text: text2, annotation: { tabId: tab.tabId, url: page.url, id: record.id } });
          changed = true;
        } catch (error) {
          showFeedback(String(error));
        }
      }
    }
    if (changed) {
      render();
      void persistOutbox().catch(() => showFeedback("Could not save annotation attachments."));
    }
  }
  var annotations = new ChromeAnnotations(syncAnnotationDrafts, (error) => showFeedback(String(error)));
  chrome.tabs.onRemoved.addListener((tabId) => annotations.closed(tabId));
  function restoreCommandDraft(command) {
    if (command.message.type !== "send") {
      return;
    }
    const draft = elementDrafts[command.chatId] ??= { next: 1, attachments: [] };
    const text2 = restorePickedElements(draft, command.attachments ?? [], command.message.text);
    emit({ type: "restoreDraft", chatId: command.chatId, text: text2 });
    render();
  }
  function cancelPick() {
    const pick = picking;
    picking = void 0;
    pickerControls.hidden = true;
    if (pick?.tabId !== void 0) {
      void chrome.scripting.executeScript({
        target: { tabId: pick.tabId },
        world: "ISOLATED",
        func: (id) => window.__aiBrowserChromeElementPicker?.cancel(id),
        args: [pick.id]
      }).catch(() => {
      });
    }
  }
  async function injectPick(pick) {
    if (picking !== pick || pick.generation !== generation || pick.tabId === void 0) {
      return;
    }
    pickerStatus.textContent = "Hover over an element and click to select it. Press Esc to cancel.";
    try {
      await chrome.scripting.executeScript({ target: { tabId: pick.tabId }, world: "ISOLATED", files: ["elementPicker.js"] });
    } catch {
      if (picking !== pick || pick.generation !== generation) {
        return;
      }
      cancelPick();
      showFeedback("Chrome denied access to this page. Check the extension's site access settings at chrome://extensions.");
      return;
    }
    if (picking !== pick || pick.generation !== generation) {
      return;
    }
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: pick.tabId },
        world: "ISOLATED",
        func: (id) => {
          const picker = window.__aiBrowserChromeElementPicker;
          if (!picker) {
            throw new Error("Element picker is unavailable");
          }
          return picker.start(id);
        },
        args: [pick.id]
      });
      if (picking !== pick || pick.generation !== generation) {
        return;
      }
      const data = results[0]?.result;
      if (!data) {
        cancelPick();
        return;
      }
      const report = renderElementMarkdown(data, data.url).replace("from Integrated Browser", "from Google Chrome") + `

CSS selector: ${inertProse(oneLine(data.selector))}`;
      if (report.length > 64e3) {
        throw new Error("The element context is too large. Select a smaller element.");
      }
      const self = data.ancestors.at(-1);
      const label = self ? formatAncestor(self).slice(0, 120) : "Element";
      const draft = elementDrafts[pick.chatId] ??= { next: 1, attachments: [] };
      appendPickedElement(draft, { id: crypto.randomUUID(), kind: "element", label, text: report });
      await persistOutbox();
      if (pick.generation === generation) {
        feedback = latest?.chatId === pick.chatId ? void 0 : "Element saved in the original conversation's draft.";
        render();
      }
    } catch (error) {
      if (pick.generation === generation) {
        showFeedback(error instanceof Error ? error.message : "Could not select the element.");
      }
    } finally {
      if (picking === pick) {
        cancelPick();
      }
    }
  }
  function startPick() {
    if (!active || !latest) {
      return;
    }
    if (!supportsFeature("elements")) {
      showFeedback(chromeChatFeatureError("elements"));
      return;
    }
    if (!latest.canAttachElements) {
      showFeedback("Update the editor extension and reconnect to attach elements.");
      return;
    }
    cancelPick();
    const pick = { id: crypto.randomUUID(), chatId: latest.chatId, generation, tabId: activePage?.id };
    picking = pick;
    pickerControls.hidden = false;
    pickerStatus.textContent = "Preparing the element picker\u2026";
    void (async () => {
      const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      if (picking !== pick || pick.generation !== generation) {
        return;
      }
      if (tab?.id === void 0 || !tab.url || pick.tabId !== void 0 && pick.tabId !== tab.id) {
        throw new Error("The active tab changed. Select the element again.");
      }
      const url = new URL(tab.url);
      if (!["http:", "https:"].includes(url.protocol) || url.hostname === "chromewebstore.google.com" || url.hostname === "chrome.google.com" && url.pathname.startsWith("/webstore")) {
        throw new Error("Elements cannot be selected on internal Chrome pages. Open a website.");
      }
      pick.tabId = tab.id;
      pick.url = url.href;
      await injectPick(pick);
    })().catch((error) => {
      if (picking === pick) {
        cancelPick();
        showFeedback(error instanceof Error ? error.message : "Could not open the element picker.");
      }
    });
  }
  async function addChromeAttachment(chatId, current, value) {
    if (current !== generation || !active) {
      return;
    }
    const draft = elementDrafts[chatId] ??= { next: 1, attachments: [] };
    const item = { ...value, id: crypto.randomUUID(), reference: `@${draft.next}` };
    if (!readChromeElementAttachments([...draft.attachments, item])) {
      throw new Error("Attachments exceed the limit: 8 items, 200,000 text characters and 4 MB of files in total.");
    }
    appendPickedElement(draft, item);
    try {
      await persistOutbox();
    } catch (error) {
      draft.attachments = draft.attachments.filter((a) => a.id !== item.id);
      throw error;
    }
    render();
  }
  async function fileAttachment(chatId, current, file, name, kind, text2 = `Attached file: ${name}`) {
    if (file.size > 4e6) {
      throw new Error("File exceeds 4 MB. Attach a smaller file.");
    }
    const base64 = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("Could not read the file."));
      reader.onload = () => resolve(String(reader.result).split(",")[1]);
      reader.readAsDataURL(file);
    });
    await addChromeAttachment(chatId, current, {
      kind,
      label: name.slice(0, 160),
      text: text2,
      file: { name, mime: file.type.split(";")[0] || "application/octet-stream", base64 }
    });
  }
  var recording;
  var recordingStarting = false;
  function chromeRecordingStatus() {
    if (!recording) {
      emit({ type: "recordingStatus", seconds: 0 });
      return;
    }
    const { recorder, started, elapsed } = recording;
    emit({
      type: "recordingStatus",
      state: recorder.state === "inactive" ? "stopping" : recorder.state === "paused" ? "paused" : "recording",
      seconds: (elapsed + (recorder.state === "recording" ? Date.now() - started : 0)) / 1e3
    });
  }
  function controlChromeRecording(action) {
    const session = recording;
    if (!session || session.recorder.state === "inactive") {
      return;
    }
    if (session.recorder.state === "recording") {
      session.elapsed += Date.now() - session.started;
      session.started = Date.now();
    }
    if (action === "stop") {
      session.recorder.stop();
    } else if (action === "pause" && session.recorder.state === "recording") {
      session.recorder.pause();
    } else if (action === "resume" && session.recorder.state === "paused") {
      session.started = Date.now();
      session.recorder.resume();
    }
    chromeRecordingStatus();
  }
  function supportsFeature(feature) {
    return !!latest && !!negotiateChromeChatCapabilities(latest.capabilities, latest.protocolVersion)[feature];
  }
  async function attachFromChrome(kind) {
    if (!latest || !active) {
      return;
    }
    const chatId = latest.chatId, current = generation;
    const feature = chromeChatAttachmentFeature(kind);
    if (feature && !supportsFeature(feature)) {
      showFeedback(chromeChatFeatureError(feature));
      return;
    }
    if (kind === "annotation") {
      cancelPick();
      const tab2 = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      if (current !== generation || tab2?.id === void 0) {
        return;
      }
      await annotations.start(tab2.id, chatId);
      return;
    }
    if (kind === "file") {
      const input = document.createElement("input");
      input.type = "file";
      input.addEventListener("change", () => {
        const file = input.files?.[0];
        if (file) {
          void fileAttachment(chatId, current, file, file.name, "file").catch((error) => showFeedback(String(error)));
        }
        input.remove();
      });
      input.addEventListener("cancel", () => input.remove());
      input.hidden = true;
      document.body.append(input);
      input.click();
      return;
    }
    if (kind === "video") {
      if (recording) {
        controlChromeRecording("stop");
        return;
      }
      if (recordingStarting) {
        return;
      }
      recordingStarting = true;
      emit({ type: "recordingStatus", state: "starting", seconds: 0 });
      let stream;
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      } catch (error) {
        if (generation === current) {
          chromeRecordingStatus();
        }
        throw error;
      } finally {
        recordingStarting = false;
      }
      if (generation !== current || !active) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      let recorder;
      try {
        recorder = new MediaRecorder(stream, { videoBitsPerSecond: 1e6 });
      } catch (error) {
        stream.getTracks().forEach((track) => track.stop());
        chromeRecordingStatus();
        throw error;
      }
      const chunks = [];
      let size = 0;
      const session = { recorder, stream, started: Date.now(), elapsed: 0 };
      recording = session;
      const timer2 = setInterval(chromeRecordingStatus, 250);
      const timeout = setTimeout(() => {
        if (recording === session) {
          controlChromeRecording("stop");
        }
      }, 2e4);
      recorder.ondataavailable = (event) => {
        chunks.push(event.data);
        size += event.data.size;
        if (size >= 35e5 && recording === session) {
          controlChromeRecording("stop");
        }
      };
      recorder.onstop = () => {
        clearTimeout(timeout);
        clearInterval(timer2);
        stream.getTracks().forEach((track) => track.stop());
        const save = chunks.length && current === generation && active ? fileAttachment(chatId, current, new Blob(chunks, { type: recorder.mimeType }), recorder.mimeType.includes("mp4") ? "recording.mp4" : "recording.webm", "video") : Promise.resolve();
        void save.catch((error) => showFeedback(String(error))).finally(() => {
          if (recording === session) {
            recording = void 0;
            chromeRecordingStatus();
          }
        });
      };
      recorder.onerror = () => {
        showFeedback("Chrome could not record the selected screen.");
        if (recording === session) {
          controlChromeRecording("stop");
        }
      };
      stream.getVideoTracks()[0].onended = () => {
        if (recording === session) {
          controlChromeRecording("stop");
        }
      };
      try {
        recorder.start(500);
        chromeRecordingStatus();
      } catch (error) {
        clearTimeout(timeout);
        clearInterval(timer2);
        stream.getTracks().forEach((track) => track.stop());
        if (recording === session) {
          recording = void 0;
          chromeRecordingStatus();
        }
        throw error;
      }
      return;
    }
    const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (!tab?.url || tab.id === void 0 || !/^https?:/.test(tab.url)) {
      throw new Error("Open a regular website in Chrome first.");
    }
    const url = new URL(tab.url);
    url.username = "";
    url.password = "";
    if (kind === "screenshot") {
      if (tab.windowId === void 0) {
        throw new Error("Chrome window unavailable.");
      }
      const data = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
      const after = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      if (after?.id !== tab.id || after.url !== tab.url) {
        throw new Error("The active page changed during capture. Try again.");
      }
      await addChromeAttachment(chatId, current, { kind: "screenshot", label: "screenshot.png", text: `Screenshot of ${url.href}`, file: { name: "screenshot.png", mime: "image/png", base64: data.split(",")[1] } });
      return;
    }
    if (kind === "page" || kind === "sharedPage") {
      await addChromeAttachment(chatId, current, {
        kind,
        label: (tab.title || url.href).slice(0, 160),
        text: `The page the user is looking at: ${url.href}
${tab.title || ""}
This address alone does not grant browser tool access. Check browser_tabs before interacting.`,
        ...kind === "sharedPage" ? { tabId: tab.id } : {}
      });
      return;
    }
    throw new Error("This attachment is unavailable in Chrome.");
  }
  cancelElementPick.addEventListener("click", cancelPick);
  window.addEventListener("pagehide", () => {
    cancelPick();
    generation++;
    controlChromeRecording("stop");
    recording?.stream.getTracks().forEach((track) => track.stop());
  });
  var pageQuery = 0;
  function refreshActivePage() {
    const current = ++pageQuery;
    void chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (current !== pageQuery) {
        return;
      }
      activePage = tabs[0];
      for (const draft of Object.values(elementDrafts)) {
        for (let index = 0; index < draft.attachments.length; index++) {
          const item = draft.attachments[index];
          if (item.kind === "sharedPage" && item.tabId === activePage?.id && activePage?.url && /^https?:/.test(activePage.url)) {
            const url = new URL(activePage.url);
            url.username = "";
            url.password = "";
            draft.attachments[index] = {
              ...item,
              label: (activePage.title || url.href).slice(0, 160),
              text: `Shared page: ${url.href}
${activePage.title || ""}
Check browser_tabs before interacting; Chrome sharing does not grant tool access.`
            };
          }
        }
      }
      if (picking?.tabId !== void 0 && (activePage?.id !== picking.tabId || picking.url && activePage?.url && picking.url !== activePage.url)) {
        cancelPick();
      }
      render();
    }).catch(() => {
      if (current === pageQuery) {
        activePage = void 0;
        render();
      }
    });
  }
  chrome.tabs.onActivated.addListener(refreshActivePage);
  chrome.tabs.onUpdated.addListener((tabId, _change, tab) => {
    let changed = false;
    if (tab.url && /^https?:/.test(tab.url)) {
      const url = new URL(tab.url);
      url.username = "";
      url.password = "";
      for (const draft of Object.values(elementDrafts)) {
        draft.attachments = draft.attachments.map((item) => {
          if (item.kind !== "sharedPage" || item.tabId !== tabId) {
            return item;
          }
          changed = true;
          return {
            ...item,
            label: (tab.title || url.href).slice(0, 160),
            text: `Shared page: ${url.href}
${tab.title || ""}
Check browser_tabs before interacting; Chrome sharing does not grant tool access.`
          };
        });
      }
    }
    if (changed) {
      void persistOutbox().catch(() => showFeedback("Could not save the shared page."));
    }
    refreshActivePage();
  });
  refreshActivePage();
  window.aiBrowserChatHost = {
    getState: () => draftState,
    setState(state) {
      draftState = state;
      void chrome.storage.session.set({ draftState: state });
    },
    postMessage(message) {
      if (message.type === "controlRecording") {
        controlChromeRecording(message.action);
        return;
      }
      if (message.type === "copy") {
        void navigator.clipboard.writeText(message.text).catch((error) => showFeedback(String(error)));
        return;
      }
      if (message.type === "openLink" && /^https?:\/\//i.test(message.url)) {
        void chrome.tabs.create({ url: message.url }).catch((error) => showFeedback(String(error)));
        return;
      }
      if (message.type === "openBrowser") {
        void chrome.tabs.create({ url: "chrome://newtab/" });
        return;
      }
      if (message.type === "attach") {
        if (message.kind === "element") {
          startPick();
        } else {
          void attachFromChrome(message.kind).catch((error) => showFeedback(error instanceof Error ? error.message : String(error)));
        }
        return;
      }
      if (message.type === "pasteFile") {
        if (!supportsFeature("files")) {
          emit({ type: "pastedFileResult", id: message.id, error: chromeChatFeatureError("files") });
          return;
        }
        const chatId2 = message.chatId;
        if (!active || !latest?.view.tabs.some((tab) => tab.chatId === chatId2 && tab.id === message.tabId)) {
          emit({ type: "pastedFileResult", id: message.id, error: "The destination chat is no longer open." });
          return;
        }
        void addChromeAttachment(chatId2, generation, {
          kind: "file",
          label: message.name.slice(0, 160),
          text: `Attached file: ${message.name}`,
          file: { name: message.name, mime: message.mime || "application/octet-stream", base64: message.base64 }
        }).then(() => emit({ type: "pastedFileResult", id: message.id }), (error) => emit({ type: "pastedFileResult", id: message.id, error: String(error) }));
        return;
      }
      if (message.type === "removeAttachment" || message.type === "openAttachment") {
        const draft = latest && elementDrafts[latest.chatId];
        const attachment = draft?.attachments.find((item) => item.id === message.id);
        if (attachment) {
          if (message.type === "removeAttachment") {
            if (attachment.annotation) {
              annotations.dismiss(attachment.annotation.tabId, attachment.annotation.id);
            }
            draft.attachments = draft.attachments.filter((item) => item.id !== message.id);
            render();
            void persistOutbox().catch(() => showFeedback("Could not save the attachment draft."));
          } else {
            const dialog = document.createElement("dialog");
            dialog.className = "chrome-element-preview";
            const close = document.createElement("button");
            close.textContent = "Close";
            close.addEventListener("click", () => dialog.close());
            const text2 = document.createElement("pre");
            text2.textContent = attachment.text;
            dialog.append(close, text2);
            if (attachment.file?.mime.startsWith("image/")) {
              const image = document.createElement("img");
              image.src = `data:${attachment.file.mime};base64,${attachment.file.base64}`;
              image.alt = attachment.label;
              image.style.maxWidth = "100%";
              dialog.append(image);
            }
            dialog.addEventListener("close", () => dialog.remove());
            document.body.append(dialog);
            dialog.showModal();
          }
          return;
        }
      }
      if (passive.has(message.type)) {
        return;
      }
      if (!supported.has(message.type)) {
        const error = "This action is available in the editor. Chrome supports chat, attachments, approvals, model selection and chat settings.";
        if (message.type === "temporaryStorage") {
          emit({ type: "temporaryStorage", error });
        }
        showFeedback(error);
        return;
      }
      if (!active || !latest) {
        return;
      }
      const chatId = latest.chatId, current = generation;
      const feature = chromeChatCommandFeature(message);
      if (!supportsFeature(feature)) {
        showFeedback(chromeChatFeatureError(feature));
        return;
      }
      if (message.type === "chooseWorkdir") {
        showFeedback("Choose the working folder in the VS Code window.");
      }
      prepareChromeMessage(message, chatId, current);
    }
  };
  var pendingSends = /* @__PURE__ */ new Set();
  function prepareChromeMessage(message, chatId, current) {
    if (message.type === "stop") {
      for (const pending2 of pendingSends) {
        if (pending2.chatId !== chatId) {
          continue;
        }
        pendingSends.delete(pending2);
        emit({ type: "restoreDraft", chatId, text: pending2.text });
      }
    }
    if (message.type !== "send") {
      enqueueChromeMessage(message, chatId, current);
      return;
    }
    const pending = { chatId, text: message.text };
    pendingSends.add(pending);
    void annotations.poll().then(() => {
      if (!pendingSends.delete(pending)) {
        return;
      }
      enqueueChromeMessage(message, chatId, current);
    }).catch((error) => {
      if (!pendingSends.delete(pending)) {
        return;
      }
      emit({ type: "restoreDraft", chatId, text: message.text });
      showFeedback(String(error));
    });
  }
  function enqueueChromeMessage(message, chatId, current) {
    if (current !== generation || !active) {
      if (message.type === "send") {
        emit({ type: "restoreDraft", chatId, text: message.text });
      }
      return;
    }
    const attachments = message.type === "send" ? elementDrafts[chatId]?.attachments.slice() : void 0;
    const command = readChromeChatCommand({ id: crypto.randomUUID(), chatId, message, ...attachments?.length ? { attachments } : {} });
    if (!command) {
      if (message.type === "send") {
        queueMicrotask(() => emit({ type: "restoreDraft", chatId, text: message.text }));
      }
      showFeedback("This message is invalid or too large (maximum 100,000 characters).");
      return;
    }
    outbox.push(command);
    feedback = void 0;
    if (message.type === "send") {
      delete elementDrafts[chatId];
      render();
    }
    void persistOutbox().then(() => flush()).catch(() => {
      outbox = outbox.filter((item) => item.id !== command.id);
      restoreCommandDraft(command);
      showFeedback("Could not save the outgoing message. Your text was returned to the draft.");
    });
  }
  async function flush() {
    if (flushing || !active || !compatible) {
      return;
    }
    flushing = true;
    const current = generation;
    const connection = active;
    try {
      while (outbox.length && current === generation) {
        const command = outbox[0];
        if (!persisted.has(command.id)) {
          return;
        }
        const commandFeature = chromeChatCommandFeature(command.message);
        if (!supportsFeature(commandFeature)) {
          outbox.shift();
          persisted.delete(command.id);
          restoreCommandDraft(command);
          await persistOutbox();
          showFeedback(chromeChatFeatureError(commandFeature));
          continue;
        }
        const unavailable = command.attachments?.map((item) => chromeChatAttachmentFeature(item.kind)).find((feature) => !supportsFeature(feature));
        if (unavailable) {
          outbox.shift();
          persisted.delete(command.id);
          restoreCommandDraft(command);
          await persistOutbox();
          showFeedback(chromeChatFeatureError(unavailable));
          continue;
        }
        let response;
        try {
          if (command.attachments?.some((item) => item.annotation)) {
            await exchangeAnnotations(connection, current);
            if (current !== generation) {
              return;
            }
          }
          response = await fetch(`${connection.url}/command`, {
            method: "POST",
            headers: bridgeHeaders(connection, true),
            body: JSON.stringify(command),
            signal: AbortSignal.timeout(1e4)
          });
        } catch {
          if (current === generation) {
            showFeedback("Message pending. Reconnecting and retrying automatically.");
          }
          return;
        }
        if (current !== generation) {
          return;
        }
        if (response.status >= 500) {
          showFeedback("Editor unavailable. The outgoing message will retry automatically.");
          return;
        }
        const result = await response.json().catch((error) => {
          if (response.ok) {
            throw error;
          }
          return { error: "Connection refused. Reconnect to the editor before sending again." };
        });
        if (current !== generation) {
          return;
        }
        if (response.status === 426) {
          requireUpdate(result.error ?? "Update both AI Browser extensions to the latest version.");
          return;
        }
        outbox.shift();
        persisted.delete(command.id);
        if (!response.ok) {
          restoreCommandDraft(command);
        } else if (command.message.type === "send") {
          for (const item of command.attachments ?? []) {
            if (item.annotation) {
              annotations.sent(item.annotation.tabId, item.annotation.id);
            }
          }
        }
        await persistOutbox();
        if (current !== generation) {
          return;
        }
        if (!response.ok) {
          showFeedback(result.error ?? "Action refused. Review the conversation in the editor.");
        } else {
          feedback = void 0;
          if (result.snapshot?.view) {
            latest = result.snapshot;
            render();
          }
        }
        if (command.message.type === "saveFeatureAi") {
          emit(response.ok ? {
            type: "featureAiSaved",
            settings: latest?.settings.featureAi,
            recordingQuality: latest?.settings.recordingQuality,
            recordingSeconds: latest?.settings.recordingSeconds
          } : { type: "featureAiSaved", error: result.error ?? "Settings were not saved." });
        }
      }
    } catch {
      showFeedback("Could not confirm delivery. Reconnecting before retrying.");
    } finally {
      flushing = false;
    }
  }
  async function reconcileDelivery(session) {
    if (outbox.length && (!session || outboxSession !== session)) {
      const pending = outbox.splice(0);
      for (const command of pending) {
        persisted.delete(command.id);
        restoreCommandDraft(command);
      }
      showFeedback("Delivery could not be confirmed after reconnecting. Pending messages were returned to their drafts. Check the conversation and Git state before retrying.");
    }
    if (outboxSession !== session) {
      outboxSession = session;
      await persistOutbox();
    }
  }
  function reset() {
    controlChromeRecording("stop");
    emit({ type: "recordingStatus", seconds: 0 });
    cancelPick();
    cancelQuickAttempt();
    generation++;
    compatible = false;
    annotationResults.clear();
    active = void 0;
    latest = void 0;
    request?.abort();
    clearTimeout(timer);
    etag = void 0;
    failures = 0;
    feedback = void 0;
    pairing.hidden = false;
    app.hidden = true;
    disconnect.hidden = true;
    conversation.hidden = true;
    modeButton.hidden = true;
    modeDetails.hidden = true;
    modeOpen = false;
    modeShownLimited = false;
    conversation.disabled = false;
  }
  function bridgeHeaders(connection, json = false) {
    return {
      Authorization: `Bearer ${connection.token}`,
      [chromeChatProtocolHeader]: String(chromeChatProtocolVersion),
      [chromeChatVersionHeader]: chromeVersion,
      [chromeChatCapabilitiesHeader]: JSON.stringify(chromeChatCapabilities),
      ...json ? { "Content-Type": "application/json" } : {}
    };
  }
  function requireUpdate(message) {
    reset();
    status.textContent = message;
    status.dataset.state = "error";
  }
  function editorCompatibility(peer) {
    return chromeChatCompatibilityError(peer.protocolVersion, chromeChatProtocolVersion, peer.editorVersion, chromeVersion) ?? (negotiateChromeChatCapabilities(peer.capabilities, peer.protocolVersion).chat ? void 0 : chromeChatFeatureError("chat"));
  }
  function pairingHeaders(secret) {
    return { [chromeChatProtocolHeader]: String(chromeChatProtocolVersion), [chromeChatVersionHeader]: chromeVersion, [chromeChatCapabilitiesHeader]: JSON.stringify(chromeChatCapabilities), "X-AI-Browser-Extension": chrome.runtime.id, ...secret ? { "X-Pairing-Secret": secret } : {} };
  }
  function cancelQuickAttempt() {
    const attempt = quickAttempt;
    quickAttempt = void 0;
    attempt?.controller.abort();
    if (attempt) {
      void fetch(`${attempt.url}/pair/${attempt.id}`, { method: "DELETE", headers: pairingHeaders(attempt.secret), signal: AbortSignal.timeout(2e3) }).catch(() => {
      });
    }
    quickConnect.disabled = false;
    cancelConnect.hidden = true;
  }
  async function requestQuickConnection(url, current) {
    if (current !== generation) {
      return;
    }
    const attempt = {
      url,
      id: crypto.randomUUID(),
      secret: Array.from(crypto.getRandomValues(new Uint8Array(32)), (value) => value.toString(16).padStart(2, "0")).join(""),
      controller: new AbortController()
    };
    quickAttempt = attempt;
    quickConnect.disabled = true;
    cancelConnect.hidden = false;
    editorSources.replaceChildren();
    status.textContent = "Click Allow in the editor chat.";
    const deadline = Date.now() + 9e4;
    const expired = setTimeout(() => attempt.controller.abort(), 9e4);
    try {
      let method = "POST";
      while (current === generation && !attempt.controller.signal.aborted) {
        const response = await fetch(`${url}/pair/${attempt.id}`, { method, headers: pairingHeaders(attempt.secret), signal: attempt.controller.signal });
        if (current !== generation) {
          return;
        }
        if (response.status === 429) {
          throw new Error("A request is already pending in the editor. Allow or deny it, then try again.");
        }
        if (response.status === 426) {
          const error = await response.json();
          throw new Error(error.error ?? "Update both AI Browser extensions.");
        }
        if (!response.ok) {
          throw new Error("The request expired or the editor is unavailable. Click Connect again.");
        }
        const result = await response.json();
        if (current !== generation) {
          return;
        }
        if (result.status === "approved") {
          const connection = readChromeChatConnection(result.connection);
          if (!connection || connection.extensionId !== chrome.runtime.id) {
            throw new Error("The editor returned invalid connection details.");
          }
          const problem = editorCompatibility(connection);
          if (problem) {
            throw new Error(problem);
          }
          const key = result.connection.resumeKey;
          await saveResume(typeof key === "string" && /^[a-f0-9]{64}$/.test(key) ? { key } : void 0);
          await outboxWrite.catch(() => {
          });
          if (current !== generation || attempt.controller.signal.aborted) {
            return;
          }
          outbox = [];
          persisted.clear();
          await chrome.storage.session.set({ connection, outbox });
          if (current !== generation || attempt.controller.signal.aborted) {
            return;
          }
          quickAttempt = void 0;
          connect(connection);
          return;
        }
        if (result.status !== "pending") {
          throw new Error("Connection denied in the editor.");
        }
        if (Date.now() >= deadline) {
          throw new Error("The request timed out.");
        }
        method = "GET";
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    } catch (error) {
      if (current === generation) {
        status.textContent = attempt.controller.signal.aborted ? "The request timed out. Try again." : error instanceof Error ? error.message : "Could not connect.";
      }
    } finally {
      clearTimeout(expired);
      if (quickAttempt === attempt) {
        cancelQuickAttempt();
      }
    }
  }
  quickConnect.addEventListener("click", () => {
    cancelQuickAttempt();
    const current = ++generation;
    quickConnect.disabled = true;
    cancelConnect.hidden = false;
    editorSources.replaceChildren();
    status.textContent = "Looking for an open editor\u2026";
    void Promise.all(chromePairingPorts.map(async (port) => {
      const url = `http://127.0.0.1:${port}`;
      try {
        const response = await fetch(`${url}/discovery`, { headers: pairingHeaders(), signal: AbortSignal.timeout(1500) });
        if (!response.ok) {
          return void 0;
        }
        const host = await response.json();
        return host.kind === chromePairingKind && host.version === 1 ? { url, label: typeof host.label === "string" ? host.label : "AI Browser", problem: editorCompatibility(host) } : void 0;
      } catch {
        return void 0;
      }
    })).then((found) => {
      if (current !== generation) {
        return;
      }
      const hosts = found.filter((host) => !!host);
      quickConnect.disabled = false;
      cancelConnect.hidden = true;
      if (!hosts.length) {
        status.textContent = "No editor found. Open a local window with an updated AI Browser extension and try again.";
        return;
      }
      if (hosts.length === 1) {
        if (hosts[0].problem) {
          status.textContent = hosts[0].problem;
          status.dataset.state = "error";
        } else {
          void requestQuickConnection(hosts[0].url, current);
        }
        return;
      }
      status.textContent = "Choose an editor window:";
      for (const host of hosts) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = host.problem ? `${host.label} \u2014 ${host.problem}` : host.label;
        button.disabled = !!host.problem;
        button.addEventListener("click", () => void requestQuickConnection(host.url, current));
        editorSources.append(button);
      }
    });
  });
  cancelConnect.addEventListener("click", () => {
    generation++;
    cancelQuickAttempt();
    editorSources.replaceChildren();
    status.textContent = "Connection cancelled.";
  });
  window.addEventListener("pagehide", cancelQuickAttempt);
  var annotationResults = /* @__PURE__ */ new Map();
  var annotationExchange;
  function exchangeAnnotations(connection, current) {
    if (annotationExchange?.generation === current) {
      return annotationExchange.promise;
    }
    const slot = { generation: current, promise: Promise.resolve() };
    slot.promise = performAnnotationExchange(connection, current).finally(() => {
      if (annotationExchange === slot) {
        annotationExchange = void 0;
      }
    });
    annotationExchange = slot;
    return slot.promise;
  }
  async function performAnnotationExchange(connection, current) {
    if (!compatible) {
      return;
    }
    const chats = new Set(latest?.view.tabs.map((tab) => tab.chatId) ?? []);
    const results = [...annotationResults.values()];
    if (!supportsFeature("annotations")) {
      return;
    }
    const response = await fetch(`${connection.url}/annotations`, {
      method: "POST",
      headers: bridgeHeaders(connection, true),
      body: JSON.stringify({ tabs: annotations.snapshot().filter((tab) => chats.has(tab.chatId)), results }),
      signal: AbortSignal.timeout(5e3)
    });
    if (response.status === 404) {
      throw new Error(chromeChatFeatureError("annotations"));
    }
    const data = await response.json();
    if (current !== generation) {
      return;
    }
    if (response.status === 426) {
      requireUpdate(data.error ?? "Update both AI Browser extensions.");
      return;
    }
    if (!response.ok) {
      throw new Error(data.error ?? "Could not synchronize Chrome annotations.");
    }
    for (const result of results) {
      annotationResults.delete(result.id);
    }
    for (const task of data.requests ?? []) {
      if (annotationResults.has(task.id)) {
        continue;
      }
      try {
        const value = await annotations.execute(task);
        if (current === generation) {
          annotationResults.set(task.id, { id: task.id, value });
        }
      } catch (error) {
        if (current === generation) {
          annotationResults.set(task.id, { id: task.id, error: String(error) });
        }
      }
      if (current !== generation) {
        return;
      }
    }
  }
  var footerCursor = 0;
  var footerSession;
  async function pollFooterEvents(connection, current) {
    if (!Object.keys(chromeChatFooterCommands).some((feature) => supportsFeature(feature))) {
      return;
    }
    const response = await fetch(`${connection.url}/events?after=${footerCursor}`, { headers: bridgeHeaders(connection), signal: AbortSignal.timeout(5e3) });
    if (!response.ok) {
      throw new Error("Could not receive editor action results.");
    }
    const result = await response.json();
    if (current !== generation) {
      return;
    }
    const previousCursor = footerCursor;
    for (const event of result.events) {
      if (event.id <= footerCursor) {
        continue;
      }
      footerCursor = event.id;
      if (event.message?.type === "chromeAttachment") {
        if (latest?.view.tabs.some((tab) => tab.chatId === event.chatId)) {
          try {
            await addChromeAttachment(event.chatId, current, { kind: "file", label: event.message.label, text: event.message.text });
          } catch (error) {
            showFeedback(String(error));
          }
        }
      } else if (event.chatId === latest?.chatId) {
        if (event.error) {
          showFeedback(event.error);
        } else if (event.message) {
          emit(event.message);
        }
      }
      if (current !== generation) {
        return;
      }
      footerCursor = event.id;
    }
    footerCursor = result.cursor;
    if (footerCursor !== previousCursor) {
      await persistOutbox();
    }
  }
  async function poll(connection, current) {
    if (latest) {
      await annotations.retainChats(new Set(latest.view.tabs.map((tab) => tab.chatId))).catch((error) => showFeedback(String(error)));
    }
    await annotations.poll();
    if (current !== generation) {
      return;
    }
    if (latest) {
      try {
        await exchangeAnnotations(connection, current);
      } catch (error) {
        if (current === generation) {
          showFeedback(String(error));
        }
      }
    }
    if (current !== generation || active !== connection) {
      return;
    }
    const controller = new AbortController();
    request = controller;
    const timeout = setTimeout(() => controller.abort(), 5e3);
    try {
      const headers = bridgeHeaders(connection);
      if (etag) {
        headers["If-None-Match"] = etag;
      }
      const response = await fetch(`${connection.url}/snapshot`, { headers, cache: "no-store", signal: controller.signal });
      if (current !== generation) {
        return;
      }
      if (response.status === 401 || response.status === 403) {
        await chrome.storage.session.remove("connection");
        if (current === generation) {
          void editorGone("The editor ended this connection.");
        }
        return;
      }
      if (response.status === 426) {
        const error = await response.json();
        requireUpdate(error.error ?? "Update both AI Browser extensions.");
        return;
      }
      if (response.status !== 304) {
        if (!response.ok) {
          throw new Error("Editor unavailable");
        }
        const snapshot = await response.json();
        if (current !== generation) {
          return;
        }
        const problem = editorCompatibility(snapshot);
        if (problem || snapshot.version !== 1 || !snapshot.view) {
          requireUpdate(problem ?? "Update both AI Browser extensions to the latest version.");
          return;
        }
        await reconcileDelivery(snapshot.deliverySession ?? `legacy:${connection.token}`);
        if (current !== generation) {
          return;
        }
        compatible = true;
        status.title = `Chrome ${chromeVersion} \xB7 VS Code ${snapshot.editorVersion ?? "unknown"}`;
        latest = snapshot;
        render();
        etag = response.headers.get("ETag") ?? void 0;
      }
      status.textContent = latest?.blocked ?? (latest?.running ? "Working\u2026" : "Connected");
      status.dataset.state = latest?.blocked ? "error" : "connected";
      await pollFooterEvents(connection, current);
      if (current !== generation) {
        return;
      }
      failures = 0;
      void flush();
    } catch {
      if (current !== generation) {
        return;
      }
      failures++;
      status.textContent = "Editor unavailable \xB7 Reconnecting\u2026";
      status.dataset.state = "error";
      if (failures >= 2) {
        void editorGone("The editor was closed or reloaded.");
        return;
      }
    } finally {
      clearTimeout(timeout);
    }
    if (current === generation) {
      timer = setTimeout(() => void poll(connection, current), failures ? Math.min(1e4, 1e3 * 2 ** Math.min(failures, 4)) : 750);
    }
  }
  function connect(connection, restoredCursor) {
    const cursor = restoredCursor ?? (footerSession && footerSession === connection.deliverySession ? footerCursor : 0);
    reset();
    active = connection;
    footerSession = connection.deliverySession;
    footerCursor = cursor;
    pairing.hidden = true;
    app.hidden = true;
    disconnect.hidden = false;
    status.textContent = "Connecting\u2026";
    delete status.dataset.state;
    void poll(connection, generation);
  }
  pairing.addEventListener("submit", (event) => {
    event.preventDefault();
    if (pairingPending) {
      return;
    }
    pairingPending = true;
    void (async () => {
      try {
        const connection = readChromeChatConnection(JSON.parse(code.value.trim()));
        if (!connection || connection.extensionId !== chrome.runtime.id) {
          throw new Error("Paste a valid connection code for this Chrome extension.");
        }
        const problem = editorCompatibility(connection);
        if (problem) {
          throw new Error(problem);
        }
        const current = ++generation;
        outbox = [];
        persisted.clear();
        await outboxWrite.catch(() => {
        });
        await chrome.storage.session.set({ connection, outbox });
        if (current !== generation) {
          return;
        }
        code.value = "";
        connect(connection);
      } catch (error) {
        status.textContent = error instanceof Error ? error.message : "Paste a valid connection code.";
        status.dataset.state = "error";
      } finally {
        pairingPending = false;
      }
    })();
  });
  disconnect.addEventListener("click", () => {
    reset();
    outbox = [];
    persisted.clear();
    status.textContent = "Disconnected from editor";
    void saveResume(void 0);
    void outboxWrite.catch(() => {
    }).then(() => chrome.storage.session.remove(["connection", "outbox"]));
  });
  var initialGeneration = generation;
  void chrome.storage.session.get(["connection", "draftState", "outbox", "elementDrafts", "annotationTabs", "footerPosition", "outboxSession"]).then((saved) => {
    if (initialGeneration !== generation) {
      return;
    }
    if (saved.draftState && typeof saved.draftState === "object") {
      draftState = saved.draftState;
      emit({ type: "hydrateDrafts", drafts: draftState.drafts ?? {} });
    }
    if (saved.elementDrafts && typeof saved.elementDrafts === "object") {
      for (const [chatId, value] of Object.entries(saved.elementDrafts)) {
        if (!value || typeof value !== "object" || chatId.length > 100) {
          continue;
        }
        const raw = value;
        const attachments = readChromeElementAttachments(raw.attachments);
        if (attachments) {
          elementDrafts[chatId] = { attachments, next: Number.isSafeInteger(raw.next) && raw.next > 0 ? raw.next : 1 };
        }
      }
    }
    annotations.restore(saved.annotationTabs);
    outbox = Array.isArray(saved.outbox) ? saved.outbox.map(readChromeChatCommand).filter((item) => !!item) : [];
    outboxSession = typeof saved.outboxSession === "string" ? saved.outboxSession : void 0;
    for (const command of outbox) {
      persisted.add(command.id);
    }
    const connection = readChromeChatConnection(saved.connection);
    const position = saved.footerPosition;
    const cursor = (position?.deliverySession ? position.deliverySession === connection?.deliverySession : position?.token === connection?.token) && Number.isSafeInteger(position?.cursor) && position.cursor >= 0 ? position.cursor : 0;
    if (connection?.extensionId === chrome.runtime.id) {
      connect(connection, cursor);
    } else {
      void resumeOnce();
    }
    watchForEditor();
  }).catch(() => {
    status.textContent = "Session storage unavailable. Reload the extension.";
  });
  var resumeState;
  var resuming = false;
  var resumeLoaded = chrome.storage.local.get("resume").then((saved) => {
    const raw = saved.resume;
    resumeState = raw && typeof raw.key === "string" && /^[a-f0-9]{64}$/.test(raw.key) ? { key: raw.key, ...typeof raw.chatId === "string" && raw.chatId.length <= 100 ? { chatId: raw.chatId } : {} } : void 0;
  }).catch(() => {
    resumeState = void 0;
  });
  async function saveResume(grant) {
    resumeState = grant;
    await (grant ? chrome.storage.local.set({ resume: grant }) : chrome.storage.local.remove("resume")).catch(() => {
    });
  }
  async function editorGone(reason) {
    reset();
    status.textContent = resumeState ? `${reason} Reconnecting automatically when it is back\u2026` : `${reason} Click Connect.`;
    status.dataset.state = "error";
    void resumeOnce();
  }
  async function resumeOnce() {
    await resumeLoaded;
    if (resuming || active || quickAttempt || !resumeState) {
      return false;
    }
    resuming = true;
    const current = generation;
    try {
      const hosts = (await Promise.all(chromePairingPorts.map(async (port) => {
        const url = `http://127.0.0.1:${port}`;
        try {
          const response = await fetch(`${url}/discovery`, { headers: pairingHeaders(), signal: AbortSignal.timeout(1e3) });
          if (!response.ok) {
            return void 0;
          }
          const host = await response.json();
          return host.kind === chromePairingKind && host.version === 1 && !editorCompatibility(host) ? url : void 0;
        } catch {
          return void 0;
        }
      }))).filter((url) => !!url);
      for (const strict of [true, false]) {
        for (const url of hosts) {
          if (current !== generation || active || !resumeState) {
            return false;
          }
          const response = await fetch(`${url}/resume`, { method: "POST", signal: AbortSignal.timeout(8e3), headers: {
            ...pairingHeaders(),
            "X-Resume-Key": resumeState.key,
            "X-Resume-Strict": strict ? "1" : "0",
            ...resumeState.chatId ? { "X-Resume-Chat": resumeState.chatId } : {}
          } }).catch(() => void 0);
          if (!response || current !== generation || active) {
            continue;
          }
          if (response.status === 401 || response.status === 403) {
            continue;
          }
          if (!response.ok) {
            continue;
          }
          const result = await response.json().catch(() => ({}));
          const connection = readChromeChatConnection(result.connection);
          if (!connection || connection.extensionId !== chrome.runtime.id || editorCompatibility(connection)) {
            continue;
          }
          await chrome.storage.session.set({ connection });
          if (current !== generation || active) {
            return false;
          }
          connect(connection);
          return true;
        }
      }
      return false;
    } finally {
      resuming = false;
    }
  }
  function watchForEditor() {
    setInterval(() => {
      if (!active && !quickAttempt && resumeState) {
        void resumeOnce();
      }
    }, 3e3);
  }
})();
